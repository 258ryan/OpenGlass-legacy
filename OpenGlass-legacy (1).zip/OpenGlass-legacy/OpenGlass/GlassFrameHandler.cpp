#include "pch.h"
#include "Shared.hpp"
#include "GlassFrameHandler.hpp"
#include "GlassKernel.hpp"
#include "uDWMProjection.hpp"
#include "dwmcoreProjection.hpp"
#include "GlassEffectBrush.hpp"
#include "GlassReflectionBrush.hpp"
#include "GlassHighlightBrush.hpp"

using namespace OpenGlass;

namespace OpenGlass::GlassFrameHandler
{
	HRESULT MyResourceHelper_CreateGeometryFromHRGN(HRGN hrgn, uDWM::CRgnGeometryProxy** geometry);
	HRESULT MyCGlassColorizationParameters_AdjustWindowColorization(
		uDWM::CGlassColorizationParameters* This,
		uDWM::GpCC* colorUnused,
		float opacity,
		BYTE flag
	);
	HRESULT MyCTopLevelWindow_UpdateNCAreaBackground(uDWM::CTopLevelWindow* This);
	HRESULT MyCTopLevelWindow_UpdateClientBlur(uDWM::CTopLevelWindow* This);
	HRESULT MyCTopLevelWindow_ValidateVisual(uDWM::CTopLevelWindow* This);
	void MyCTopLevelWindow_Destructor(uDWM::CTopLevelWindow* This);

	decltype(&MyResourceHelper_CreateGeometryFromHRGN) g_ResourceHelper_CreateGeometryFromHRGN_Org{ nullptr };
	decltype(&MyCGlassColorizationParameters_AdjustWindowColorization) g_CGlassColorizationParameters_AdjustWindowColorization_Org{ nullptr };
	decltype(&MyCTopLevelWindow_UpdateNCAreaBackground) g_CTopLevelWindow_UpdateNCAreaBackground_Org{ nullptr };
	decltype(&MyCTopLevelWindow_UpdateClientBlur) g_CTopLevelWindow_UpdateClientBlur_Org{ nullptr };
	decltype(&MyCTopLevelWindow_ValidateVisual) g_CTopLevelWindow_ValidateVisual_Org{ nullptr };
	decltype(&MyCTopLevelWindow_Destructor) g_CTopLevelWindow_Destructor_Org{ nullptr };
	
	wil::unique_hrgn g_combinedRgn{ nullptr };

	HRESULT UpdateReflectionViewport(uDWM::CTopLevelWindow* window);

	HRESULT UpdateHighlightViewport(uDWM::CTopLevelWindow* window);
	HRESULT UpdateHighlightGeometry(uDWM::CTopLevelWindow* window);
}

HRESULT GlassFrameHandler::UpdateReflectionViewport(uDWM::CTopLevelWindow* window)
{
	const auto active = window->TreatAsActiveWindow();
	const auto maximized = window->TreatAsMaximized();
	const auto desktop = window->GetTransformParent();
	const auto opacity = GlassKernel::ImageOpacityReinterpreter(active, maximized, true).ToFloat();
	if (
		const auto legacyVisual = window->GetLegacyVisual();
		legacyVisual
	)
	{
		if (
			const auto brush = GlassReflectionBrush::GetOrCreate(window, 0);
			brush &&
			!window->IsOffscreen()
		)
		{
			RETURN_IF_FAILED(
				brush->Update(
					(Shared::g_reflectionPolicy & Shared::ReflectionPolicy::NonClient) ?
					opacity :
					0.f,
					GlassReflectionBrush::CalculateTargetViewport(
						legacyVisual->GetLocalToParentVisualOffset(desktop),
						Shared::g_reflectionParallaxIntensity,
						window->IsRTLMirrored(),
						legacyVisual->GetWidth(),
						legacyVisual->GetScale()
					),
					D2D1::RectF(),
					nullptr,
					DWM::MilBrushMappingMode::Absolute,
					DWM::MilBrushMappingMode::Absolute,
					nullptr,
					nullptr,
					DWM::MilStretch::None,
					DWM::MilTileMode::Extend,
					DWM::MilHorizontalAlignment::Left,
					DWM::MilVerticalAlignment::Top,
					nullptr
				)
			);
		}
	}
	if (
		const auto clientBlurVisual = window->GetClientBlurVisual();
		clientBlurVisual
	)
	{
		if (
			const auto brush = GlassReflectionBrush::GetOrCreate(window, 1);
			brush &&
			!window->IsOffscreen()
		)
		{
			RETURN_IF_FAILED(
				brush->Update(
					(Shared::g_reflectionPolicy & Shared::ReflectionPolicy::NonClient) ?
					opacity :
					0.f,
					GlassReflectionBrush::CalculateTargetViewport(
						clientBlurVisual->GetLocalToParentVisualOffset(desktop),
						Shared::g_reflectionParallaxIntensity,
						window->IsRTLMirrored(),
						clientBlurVisual->GetWidth(),
						clientBlurVisual->GetScale()
					),
					D2D1::RectF(),
					nullptr,
					DWM::MilBrushMappingMode::Absolute,
					DWM::MilBrushMappingMode::Absolute,
					nullptr,
					nullptr,
					DWM::MilStretch::None,
					DWM::MilTileMode::Extend,
					DWM::MilHorizontalAlignment::Left,
					DWM::MilVerticalAlignment::Top,
					nullptr
				)
			);
		}
	}
	if (
		const auto accentVisual = window->GetAccent();
		accentVisual
	)
	{
		if (
			const auto brush = GlassReflectionBrush::GetOrCreate(window, 2);
			brush &&
			!window->IsOffscreen()
		)
		{
			RETURN_IF_FAILED(
				brush->Update(
					(Shared::g_reflectionPolicy & Shared::ReflectionPolicy::NonClient) ?
					opacity :
					0.f,
					GlassReflectionBrush::CalculateTargetViewport(
						accentVisual->GetLocalToParentVisualOffset(desktop),
						Shared::g_reflectionParallaxIntensity,
						window->IsRTLMirrored(),
						accentVisual->GetWidth(),
						accentVisual->GetScale()
					),
					D2D1::RectF(),
					nullptr,
					DWM::MilBrushMappingMode::Absolute,
					DWM::MilBrushMappingMode::Absolute,
					nullptr,
					nullptr,
					DWM::MilStretch::None,
					DWM::MilTileMode::Extend,
					DWM::MilHorizontalAlignment::Left,
					DWM::MilVerticalAlignment::Top,
					nullptr
				)
			);
		}
	}

	return S_OK;
}

HRESULT GlassFrameHandler::UpdateHighlightViewport(uDWM::CTopLevelWindow* window)
{
	const auto active = window->TreatAsActiveWindow();
	const auto maximized = window->TreatAsMaximized();
	const auto sheetOfGlass = window->GetData()->IsSheetOfGlass();
	const auto insideMargins = window->GetFrameInsideMargins();
	const auto outsideMargins = window->GetFrameOutsideMargins(maximized);
	RECT windowRect{};
	window->GetActualWindowRect(&windowRect, true, false, true);
	const auto opacity = GlassKernel::ImageOpacityReinterpreter(active, maximized, false, false, sheetOfGlass).ToFloat();
	if (
		const auto legacyVisual = window->GetLegacyVisual();
		legacyVisual
		)
	{
		if (
			const auto brush = GlassHighlightBrush::GetOrCreate(window, 0);
			brush &&
			!window->IsOffscreen()
			)
		{
			RETURN_IF_FAILED(
				brush->Update(
					(Shared::g_reflectionPolicy & Shared::ReflectionPolicy::NonClient) ?
					opacity :
					0.f,
					GlassHighlightBrush::CalculateTargetViewport(
						{ maximized ? 0 : windowRect.left, maximized ? 0 : windowRect.top },
						{ maximized ? legacyVisual->GetWidth() : windowRect.right, maximized ? legacyVisual->GetHeight() : windowRect.bottom },
						legacyVisual->GetScale()
					),
					D2D1::RectF(
						insideMargins.cxLeftWidth - outsideMargins.cxLeftWidth,
						insideMargins.cyTopHeight - outsideMargins.cyTopHeight,
						insideMargins.cxRightWidth - outsideMargins.cxRightWidth,
						insideMargins.cyBottomHeight - outsideMargins.cyBottomHeight
					),
					nullptr,
					DWM::MilBrushMappingMode::Absolute,
					DWM::MilBrushMappingMode::Absolute,
					nullptr,
					nullptr,
					DWM::MilStretch::None,
					DWM::MilTileMode::Extend,
					DWM::MilHorizontalAlignment::Left,
					DWM::MilVerticalAlignment::Top,
					nullptr
				)
			);
		}
	}

	return S_OK;
}

HRESULT GlassFrameHandler::UpdateHighlightGeometry(uDWM::CTopLevelWindow* window)
{
	// don't update the geometry for minimized windows
	if (window->IsOffscreen())
	{
		return S_OK;
	}

	const auto maximized = window->TreatAsMaximized();
	const auto sheetOfGlass = window->GetData()->IsSheetOfGlass();
	const auto outsideMargins = window->GetFrameOutsideMargins(maximized);
	const auto insideMargins = window->GetFrameInsideMargins();

	int x1 = outsideMargins.cxLeftWidth + 1;
	int y1 = outsideMargins.cyTopHeight + 1;
	int x2 = window->GetSize().cx - outsideMargins.cxRightWidth - 1;
	int y2 = window->GetSize().cy - outsideMargins.cyBottomHeight - 1;
	int wxh = maximized ? 0 : 2 * Shared::g_roundRectRadius;

	wil::unique_hrgn outsideRegion
	{
		CreateRoundRectRgn(
			x1,
			y1,
			((x1 > x2) ? x1 : x2) + 1,
			((y1 > y2) ? y1 : y2) + 1,
			wxh, wxh
		)
	};
	RETURN_LAST_ERROR_IF_NULL(outsideRegion);

	RETURN_IF_FAILED(window->ApplyMaximizedClip(outsideRegion.get()));

	if (sheetOfGlass)
	{
		GlassHighlightBrush::CreateOrUpdateGeometry(window, 0, outsideRegion.get());
		return S_OK;
	}

	x1 = insideMargins.cxLeftWidth - 1;
	y1 = insideMargins.cyTopHeight - 1;
	x2 = window->GetSize().cx - insideMargins.cxRightWidth + 1;
	y2 = window->GetSize().cy - insideMargins.cyBottomHeight + 1;

	wil::unique_hrgn insideRegion
	{
		CreateRoundRectRgn(
			x1,
			y1,
			((x1 > x2) ? x1 : x2) + 1,
			((y1 > y2) ? y1 : y2) + 1,
			2, 2
		)
	};
	RETURN_LAST_ERROR_IF_NULL(insideRegion);

	CombineRgn(outsideRegion.get(), outsideRegion.get(), insideRegion.get(), RGN_DIFF);
	RETURN_LAST_ERROR_IF_NULL(outsideRegion);

	GlassHighlightBrush::CreateOrUpdateGeometry(window, 0, outsideRegion.get());

	return S_OK;
}

HRESULT GlassFrameHandler::MyResourceHelper_CreateGeometryFromHRGN(HRGN hrgn, uDWM::CRgnGeometryProxy** geometry)
{
	if (g_combinedRgn)
	{
		CombineRgn(
			g_combinedRgn.get(),
			g_combinedRgn.get(),
			hrgn,
			RGN_OR
		);
	}

	return g_ResourceHelper_CreateGeometryFromHRGN_Org(
		hrgn,
		geometry
	);
}

HRESULT GlassFrameHandler::MyCGlassColorizationParameters_AdjustWindowColorization(
	uDWM::CGlassColorizationParameters* This,
	[[maybe_unused]] uDWM::GpCC* colorUnused,
	[[maybe_unused]] float opacity,
	BYTE flag
)
{
	const auto active = (flag & 1) != 0;
	const auto maximized = GlassKernel::g_window ? GlassKernel::g_window->TreatAsMaximized() : false;

	This->color = Color::ToArgb(
		Color::scRGBTosRGB(
			GlassKernel::RealizeWindowColorization(
				GlassKernel::GetBaseColor(Shared::IsTransparencyDisabled(), maximized),
				GlassKernel::GetSourceColor(active),
				GlassKernel::GetColorizationOpacity(active, maximized),
				Shared::IsTransparencyDisabled(),
				false
			).GetEffectivescRGBBlendColor(0.f),
			0.f
		)
	);
	This->afterglow = 0;
	This->colorBalance = 100;
	This->afterglowBalance = 0;
	This->blurBalance = 0;
	This->windowColorization = TRUE;
	This->glassAttribute = 0;

	return S_OK;
}

HRESULT GlassFrameHandler::MyCTopLevelWindow_UpdateNCAreaBackground(uDWM::CTopLevelWindow* This)
{
	const auto active = This->TreatAsActiveWindow();
	const auto maximized = This->TreatAsMaximized();

	HRESULT hr{ S_OK };
	GlassKernel::g_redirectFirstCreateRectRgnCall = true;
	g_combinedRgn.reset(CreateRectRgn(0, 0, 0, 0));
	const auto combinedRgnScope = wil::scope_exit([] { GlassKernel::g_redirectFirstCreateRectRgnCall = std::nullopt; g_combinedRgn.reset(); });
	hr = g_CTopLevelWindow_UpdateNCAreaBackground_Org(This);

	auto effectBrush = GlassEffectBrush::GetOrCreate(This);

	if (
		const auto legacyVisual = This->GetLegacyVisual();
		legacyVisual &&
		SUCCEEDED(legacyVisual->_ValidateVisual()) &&
		!legacyVisual->IsEmpty()
	)
	{
		const auto reflectionBrush = GlassReflectionBrush::GetOrCreate(
			This,
			0,
			true
		);
		const auto highlightBrush = GlassHighlightBrush::GetOrCreate(
			This,
			0,
			true
		);
		if (!effectBrush)
		{
			effectBrush = GlassEffectBrush::GetOrCreate(This, true);

			if (Shared::g_overrideAccent)
			{
				if (
					const auto accentVisual = This->GetAccent();
					accentVisual
				)
				{
					accentVisual->SetDirtyFlags(0x1000);
				}
			}
		}

		winrt::com_ptr<uDWM::CRgnGeometryProxy> captionGeometry{ nullptr };
		winrt::com_ptr<uDWM::CBaseLegacyMilBrushProxy> brush{ nullptr };
		{
			const auto instruction = reinterpret_cast<uDWM::CDrawGeometryInstruction*>(legacyVisual->GetInstructions().views().front());
			brush.copy_from(instruction->GetBrush());
			captionGeometry.copy_from(reinterpret_cast<uDWM::CRgnGeometryProxy*>(instruction->GetGeometry()));
			RETURN_IF_FAILED(
				uDWM::ResourceHelper::CreateGeometryFromHRGN(
					g_combinedRgn.get(),
					reinterpret_cast<uDWM::CRgnGeometryProxy**>(&captionGeometry)
				)
			);
		}

		if (brush.get() != effectBrush.get())
		{
			RETURN_IF_FAILED(UpdateHighlightGeometry(This));
			const auto highlightGeometry = GlassHighlightBrush::CreateOrUpdateGeometry(This, 0);

			RETURN_IF_FAILED(legacyVisual->ClearInstructions());
			winrt::com_ptr<uDWM::CDrawGeometryInstruction> instruction{};
			RETURN_IF_FAILED(
				uDWM::CDrawGeometryInstruction::Create(
					effectBrush.get(),
					captionGeometry.get(),
					instruction.put()
				)
			);
			RETURN_IF_FAILED(legacyVisual->AddInstruction(instruction.get()));
			RETURN_IF_FAILED(
				uDWM::CDrawGeometryInstruction::Create(
					reflectionBrush.get(),
					captionGeometry.get(),
					instruction.put()
				)
			);
			RETURN_IF_FAILED(legacyVisual->AddInstruction(instruction.get()));
			RETURN_IF_FAILED(
				uDWM::CDrawGeometryInstruction::Create(
					highlightBrush.get(),
					highlightGeometry.get(),
					instruction.put()
				)
			);
			RETURN_IF_FAILED(legacyVisual->AddInstruction(instruction.get()));
		}

		if (!This->IsOffscreen())
		{
			RETURN_IF_FAILED(
				reflectionBrush->Update(
					(Shared::g_reflectionPolicy & Shared::ReflectionPolicy::NonClient) ?
					GlassKernel::ImageOpacityReinterpreter(active, maximized, true).ToFloat() :
					0.f,
					GlassReflectionBrush::CalculateTargetViewport(
						legacyVisual->GetLocalToParentVisualOffset(This->GetTransformParent()),
						Shared::g_reflectionParallaxIntensity,
						This->IsRTLMirrored(),
						legacyVisual->GetWidth(),
						legacyVisual->GetScale()
					),
					D2D1::RectF(),
					nullptr,
					DWM::MilBrushMappingMode::Absolute,
					DWM::MilBrushMappingMode::Absolute,
					nullptr,
					nullptr,
					DWM::MilStretch::None,
					DWM::MilTileMode::Extend,
					DWM::MilHorizontalAlignment::Left,
					DWM::MilVerticalAlignment::Top,
					nullptr
				)
			);
		}
	}

	// if fTransitionOnMaximized is specified,
	// we should also update the brush even the nonclient area is empty
	if (effectBrush)
	{
		auto color = This->GetCaptionColorizationParameters()->getArgbcolor();
		color.a = GlassKernel::AlphaChannelReinterpreter(active, maximized).ToFloat();
		RETURN_IF_FAILED(effectBrush->Update(1.0, color));
	}
	else if (Shared::g_overrideAccent)
	{
		if (
			const auto accentVisual = This->GetAccent();
			accentVisual
		)
		{
			accentVisual->SetDirtyFlags(0x1000);
		}
	}

	return hr;
}

HRESULT GlassFrameHandler::MyCTopLevelWindow_UpdateClientBlur(uDWM::CTopLevelWindow* This)
{
	const auto hr = g_CTopLevelWindow_UpdateClientBlur_Org(This);

	const auto active = This->TreatAsActiveWindow();
	const auto maximized = This->TreatAsMaximized();

	auto effectBrush = GlassEffectBrush::GetOrCreate(This);

	if (
		const auto clientBlurVisual = This->GetClientBlurVisual();
		clientBlurVisual &&
		!clientBlurVisual->IsEmpty()
	)
	{
		const auto reflectionBrush = GlassReflectionBrush::GetOrCreate(
			This,
			1,
			true
		);
		if (!effectBrush)
		{
			effectBrush = GlassEffectBrush::GetOrCreate(This, true);

			if (Shared::g_overrideAccent)
			{
				if (
					const auto accentVisual = This->GetAccent();
					accentVisual
				)
				{
					accentVisual->SetDirtyFlags(0x1000);
				}
			}
		}

		winrt::com_ptr<uDWM::CRgnGeometryProxy> clientBlurGeometry{ nullptr };
		winrt::com_ptr<uDWM::CBaseLegacyMilBrushProxy> brush{ nullptr };
		{
			const auto instruction = reinterpret_cast<uDWM::CDrawGeometryInstruction*>(clientBlurVisual->GetInstructions().views().front());
			brush.copy_from(instruction->GetBrush());
			clientBlurGeometry.copy_from(reinterpret_cast<uDWM::CRgnGeometryProxy*>(instruction->GetGeometry()));
		}

		if (brush.get() != effectBrush.get())
		{
			RETURN_IF_FAILED(clientBlurVisual->ClearInstructions());
			winrt::com_ptr<uDWM::CDrawGeometryInstruction> instruction{};
			RETURN_IF_FAILED(
				uDWM::CDrawGeometryInstruction::Create(
					effectBrush.get(),
					clientBlurGeometry.get(),
					instruction.put()
				)
			);
			RETURN_IF_FAILED(clientBlurVisual->AddInstruction(instruction.get()));
			RETURN_IF_FAILED(
				uDWM::CDrawGeometryInstruction::Create(
					reflectionBrush.get(),
					clientBlurGeometry.get(),
					instruction.put()
				)
			);
			RETURN_IF_FAILED(clientBlurVisual->AddInstruction(instruction.get()));
		}

		if (!This->IsOffscreen())
		{
			RETURN_IF_FAILED(
				reflectionBrush->Update(
					(Shared::g_reflectionPolicy & Shared::ReflectionPolicy::NonClient) ?
					GlassKernel::ImageOpacityReinterpreter(active, maximized, true).ToFloat() :
					0.f,
					GlassReflectionBrush::CalculateTargetViewport(
						clientBlurVisual->GetLocalToParentVisualOffset(This->GetTransformParent()),
						Shared::g_reflectionParallaxIntensity,
						This->IsRTLMirrored(),
						clientBlurVisual->GetWidth(),
						clientBlurVisual->GetScale()
					),
					D2D1::RectF(),
					nullptr,
					DWM::MilBrushMappingMode::Absolute,
					DWM::MilBrushMappingMode::Absolute,
					nullptr,
					nullptr,
					DWM::MilStretch::None,
					DWM::MilTileMode::Extend,
					DWM::MilHorizontalAlignment::Left,
					DWM::MilVerticalAlignment::Top,
					nullptr
				)
			);
		}
	}

	// if fTransitionOnMaximized is specified,
	// we should also update the brush even the nonclient area is empty
	if (effectBrush)
	{
		auto color = This->GetCaptionColorizationParameters()->getArgbcolor();
		color.a = GlassKernel::AlphaChannelReinterpreter(active, maximized).ToFloat();
		RETURN_IF_FAILED(effectBrush->Update(1.0, color));
	}
	else if (Shared::g_overrideAccent)
	{
		if (
			const auto accentVisual = This->GetAccent();
			accentVisual
		)
		{
			accentVisual->SetDirtyFlags(0x1000);
		}
	}

	return hr;
}

HRESULT GlassFrameHandler::MyCTopLevelWindow_ValidateVisual(uDWM::CTopLevelWindow* This)
{
	auto data = This->GetData();
	if (!data)
	{
		return g_CTopLevelWindow_ValidateVisual_Org(This);
	}

	GlassKernel::g_window = This;
	const auto updateReflectionBeforeLeave = wil::scope_exit([This]
	{
		GlassKernel::g_window = nullptr;
		LOG_IF_FAILED(UpdateReflectionViewport(This));
		LOG_IF_FAILED(UpdateHighlightViewport(This));
		LOG_IF_FAILED(UpdateHighlightGeometry(This));
	});
	
	return g_CTopLevelWindow_ValidateVisual_Org(This);
}

void GlassFrameHandler::MyCTopLevelWindow_Destructor(uDWM::CTopLevelWindow* This)
{
	GlassReflectionBrush::Remove(This);
	GlassEffectBrush::Remove(This);
	return g_CTopLevelWindow_Destructor_Org(This);
}

void GlassFrameHandler::Update([[maybe_unused]] GlassEngine::UpdateType type)
{
}

void GlassFrameHandler::Startup()
{
	if (Shared::g_disabledHooks.test(Shared::DisabledHooks_GlassFrameHandler))
	{
		return;
	}

	uDWM::g_projectionArray.ApplyToVariable("CGlassColorizationParameters::AdjustWindowColorization", g_CGlassColorizationParameters_AdjustWindowColorization_Org);
	uDWM::g_projectionArray.ApplyToVariable("ResourceHelper::CreateGeometryFromHRGN", g_ResourceHelper_CreateGeometryFromHRGN_Org);
	uDWM::g_projectionArray.ApplyToVariable("CTopLevelWindow::UpdateNCAreaBackground", g_CTopLevelWindow_UpdateNCAreaBackground_Org);
	uDWM::g_projectionArray.ApplyToVariable("CTopLevelWindow::UpdateClientBlur", g_CTopLevelWindow_UpdateClientBlur_Org);
	uDWM::g_projectionArray.ApplyToVariable("CTopLevelWindow::ValidateVisual", g_CTopLevelWindow_ValidateVisual_Org);
	uDWM::g_projectionArray.ApplyToVariable("CTopLevelWindow::~CTopLevelWindow", g_CTopLevelWindow_Destructor_Org);

	HookHelper::PatchFunctions(
		std::initializer_list<HookHelper::DetourInfo>
		{
			{ &g_CGlassColorizationParameters_AdjustWindowColorization_Org, &MyCGlassColorizationParameters_AdjustWindowColorization },
			{ &g_ResourceHelper_CreateGeometryFromHRGN_Org, &MyResourceHelper_CreateGeometryFromHRGN },
			{ &g_CTopLevelWindow_UpdateNCAreaBackground_Org, &MyCTopLevelWindow_UpdateNCAreaBackground },
			{ &g_CTopLevelWindow_UpdateClientBlur_Org, &MyCTopLevelWindow_UpdateClientBlur },

			{ &g_CTopLevelWindow_Destructor_Org, &MyCTopLevelWindow_Destructor },
			{ &g_CTopLevelWindow_ValidateVisual_Org, &MyCTopLevelWindow_ValidateVisual }
		},
		true
	);
}

void GlassFrameHandler::Shutdown()
{
	if (Shared::g_disabledHooks.test(Shared::DisabledHooks_GlassFrameHandler))
	{
		return;
	}

	HookHelper::PatchFunctions(
		std::initializer_list<HookHelper::DetourInfo>
		{
			{ &g_CGlassColorizationParameters_AdjustWindowColorization_Org, &MyCGlassColorizationParameters_AdjustWindowColorization },
			{ &g_ResourceHelper_CreateGeometryFromHRGN_Org, &MyResourceHelper_CreateGeometryFromHRGN },
			{ &g_CTopLevelWindow_UpdateNCAreaBackground_Org, &MyCTopLevelWindow_UpdateNCAreaBackground },
			{ &g_CTopLevelWindow_UpdateClientBlur_Org, &MyCTopLevelWindow_UpdateClientBlur },

			{ &g_CTopLevelWindow_Destructor_Org, &MyCTopLevelWindow_Destructor },
			{ &g_CTopLevelWindow_ValidateVisual_Org, &MyCTopLevelWindow_ValidateVisual }
		},
		false
	);

	SwitchToThread();

	g_combinedRgn.reset();
}
