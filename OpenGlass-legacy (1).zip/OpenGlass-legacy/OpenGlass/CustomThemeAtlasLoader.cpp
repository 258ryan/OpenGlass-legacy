#include "pch.h"
#include "MsstyleInternals.hpp"
#include "Shared.hpp"
#include "HookHelper.hpp"
#include "uDWMProjection.hpp"
#include "CustomThemeAtlasLoader.hpp"

using namespace OpenGlass;
namespace OpenGlass::CustomThemeAtlasLoader
{
	decltype(&MyGetThemeStream) g_GetThemeStream_Org{};
	decltype(&MyGetThemeMargins) g_GetThemeMargins_Org{};
	decltype(&MyGetThemeRect) g_GetThemeRect_Org{};
	decltype(&MyGetThemeInt) g_GetThemeInt_Org{};
	decltype(&MyGetThemeColor) g_GetThemeColor_Org{};

	constexpr size_t make_theme_atlas_layout_key(
		int iPartId,
		int iStateId,
		int iPropId
	)
	{
		const auto u1 = static_cast<size_t>(static_cast<uint16_t>(iPartId));
		const auto u2 = static_cast<size_t>(static_cast<uint16_t>(iStateId));
		const auto ui = static_cast<size_t>(static_cast<uint32_t>(iPropId));
		return (u1 << 48) | (u2 << 32) | ui;
	}
	HRESULT LoadThemeAtlas(LPCWSTR themeAtlasPath);
	void LoadThemeAtlasLayout(LPCWSTR themeAtlasLayoutPath);
	HRESULT LoadTextGlowFromThemeAtlas();
	void LoadHighlights();
	void LoadTheme(
		LPCWSTR themeAtlasPath,
		LPCWSTR themeAtlasLayoutPath
	);

	enum class CompatibilityQuirk
	{
		None,
		RS1
	};
	auto g_themeAtlasLayoutQuirk = CompatibilityQuirk::None;
	std::unordered_map<size_t, MARGINS> g_themeAtlasLayoutMap{};
	std::unique_ptr<BYTE[]> g_themeAtlasStream{};
	UINT g_themeAtlasStreamSize{};
	wil::unique_htheme g_themeHandle{};
	void UnloadTheme()
	{
		Shared::g_textGlowBitmap.reset();
		Shared::g_themeHighlightAssets.store(nullptr);

		g_themeAtlasStream.reset();
		g_themeAtlasStreamSize = 0;
		g_themeAtlasLayoutMap.clear();
		g_themeAtlasLayoutQuirk = CompatibilityQuirk::None;
		Shared::g_dontDeflateInactiveFrameGeometry = true;
		Shared::g_captionHeight = std::nullopt;

		g_themeHandle.reset();
	}
}

HRESULT CustomThemeAtlasLoader::MyGetThemeStream(
	HTHEME hTheme,
	int iPartId,
	int iStateId,
	int iPropId,
	VOID** ppvStream,
	DWORD* pcbStream,
	HINSTANCE hInst
)
{
	if (
		hTheme != g_themeHandle.get() ||
		iPartId ||
		iStateId ||
		iPropId != TMT_DISKSTREAM ||
		!g_themeAtlasStreamSize
	)
	{
		return g_GetThemeStream_Org(hTheme, iPartId, iStateId, iPropId, ppvStream, pcbStream, hInst);
	}

	*ppvStream = g_themeAtlasStream.get();
	*pcbStream = g_themeAtlasStreamSize;
	return S_OK;
}

HRESULT CustomThemeAtlasLoader::MyGetThemeMargins(
	HTHEME hTheme,
	HDC hdc,
	int iPartId,
	int iStateId,
	int iPropId,
	LPCRECT prc,
	MARGINS* pMargins
)
{
	decltype(g_themeAtlasLayoutMap)::iterator it;
	if (
		hTheme != g_themeHandle.get() ||
		(
			it = g_themeAtlasLayoutMap.find(
				make_theme_atlas_layout_key(
					iPartId,
					iStateId,
					iPropId
				)
			)
		) == g_themeAtlasLayoutMap.end()
	)
	{
		return g_GetThemeMargins_Org(hTheme, hdc, iPartId, iStateId, iPropId, prc, pMargins);
	}

	*pMargins = it->second;
	return S_OK;
}

HRESULT CustomThemeAtlasLoader::MyGetThemeRect(
	HTHEME hTheme,
	int iPartId,
	int iStateId,
	int iPropId,
	LPRECT pRect
)
{
	decltype(g_themeAtlasLayoutMap)::iterator it;
	if (
		hTheme != g_themeHandle.get() ||
		(
			it = g_themeAtlasLayoutMap.find(
				make_theme_atlas_layout_key(
					iPartId,
					iStateId,
					iPropId
				)
			)
		) == g_themeAtlasLayoutMap.end()
	)
	{
		return g_GetThemeRect_Org(hTheme, iPartId, iStateId, iPropId, pRect);
	}

	memcpy_s(
		pRect,
		sizeof(*pRect),
		&it->second,
		sizeof(it->second)
	);
	return S_OK;
}

// openglass exclusive
HRESULT CustomThemeAtlasLoader::MyGetThemeInt(
	HTHEME hTheme,
	int iPartId,
	int iStateId,
	int iPropId,
	int* piVal
)
{
	decltype(g_themeAtlasLayoutMap)::iterator it;
	if (
		hTheme != g_themeHandle.get() ||
		(
			it = g_themeAtlasLayoutMap.find(
				make_theme_atlas_layout_key(
					iPartId,
					iStateId,
					iPropId
				)
			)
		) == g_themeAtlasLayoutMap.end()
	)
	{
		return g_GetThemeInt_Org(hTheme, iPartId, iStateId, iPropId, piVal);
	}

	*piVal = it->second.cxLeftWidth;
	return S_OK;
}

HRESULT CustomThemeAtlasLoader::MyGetThemeColor(
	HTHEME hTheme,
	int iPartId,
	int iStateId,
	int iPropId,
	COLORREF* pColor
)
{
	decltype(g_themeAtlasLayoutMap)::iterator it;
	if (
		hTheme != g_themeHandle.get() ||
		(
			it = g_themeAtlasLayoutMap.find(
				make_theme_atlas_layout_key(
					iPartId,
					iStateId,
					iPropId
				)
			)
		) == g_themeAtlasLayoutMap.end()
	)
	{
		return g_GetThemeColor_Org(hTheme, iPartId, iStateId, iPropId, pColor);
	}

	*pColor = RGB(it->second.cxLeftWidth, it->second.cxRightWidth, it->second.cyTopHeight);
	return S_OK;
}

HTHEME CustomThemeAtlasLoader::GetThemeHandle()
{
	return g_themeHandle.get();
}

HRESULT CustomThemeAtlasLoader::LoadThemeAtlas(LPCWSTR themeAtlasPath)
{
	if (
		wcslen(themeAtlasPath) != 0 &&
		!PathIsRelativeW(themeAtlasPath) &&
		!PathIsNetworkPathW(themeAtlasPath) &&
		PathFileExistsW(themeAtlasPath)
	)
	{
		wil::unique_hfile file{ CreateFileW(themeAtlasPath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, 0) };
		RETURN_LAST_ERROR_IF(!file.is_valid());

		LARGE_INTEGER fileSize{};
		RETURN_IF_WIN32_BOOL_FALSE(GetFileSizeEx(file.get(), &fileSize));

		g_themeAtlasStreamSize = static_cast<UINT>(fileSize.QuadPart);
		g_themeAtlasStream = std::make_unique<BYTE[]>(g_themeAtlasStreamSize);
		RETURN_IF_WIN32_BOOL_FALSE(ReadFile(file.get(), g_themeAtlasStream.get(), g_themeAtlasStreamSize, nullptr, nullptr));
	}
	else
	{
		WCHAR themeFileName[MAX_PATH]{};
		RETURN_IF_FAILED(
			GetCurrentThemeName(
				themeFileName,
				std::size(themeFileName),
				nullptr,
				0,
				nullptr,
				0
			)
		);

		wil::unique_hmodule themeResource{ LoadLibraryExW(themeFileName, nullptr, LOAD_LIBRARY_AS_DATAFILE | LOAD_LIBRARY_SEARCH_SYSTEM32) };
		RETURN_LAST_ERROR_IF_NULL(themeResource);

		PVOID streamAddress;
		DWORD streamSize;
		RETURN_IF_FAILED(
			GetThemeStream(
				g_themeHandle.get(),
				static_cast<int>(DWM_WINDOW_THEME_PART::COMMON),
				0,
				TMT_DISKSTREAM,
				&streamAddress,
				&streamSize,
				themeResource.get()
			)
		);

		g_themeAtlasStreamSize = streamSize;
		g_themeAtlasStream = std::make_unique<BYTE[]>(g_themeAtlasStreamSize);
		memcpy_s(
			g_themeAtlasStream.get(),
			g_themeAtlasStreamSize,
			streamAddress,
			streamSize
		);
	}

	return S_OK;
}

void CustomThemeAtlasLoader::LoadThemeAtlasLayout(LPCWSTR themeAtlasLayoutPath)
{
	FILE* file{};
	_wfopen_s(&file, themeAtlasLayoutPath, L"r");
	if (!file)
	{
		return;
	}

	WCHAR strideBuffer[255]{};
	while (!feof(file))
	{
		fgetws(strideBuffer, std::size(strideBuffer), file);

		if (strideBuffer[0] != L'#')
		{
			MARGINS part{};
			MARGINS data{};
			WCHAR keyBuffer[64]{};
			if (
				swscanf_s(
					strideBuffer,
					L"%[^=]=%d,%d,%d,%d",
					keyBuffer,
					static_cast<unsigned int>(std::size(keyBuffer)),
					&data.cxLeftWidth,
					&data.cxRightWidth,
					&data.cyTopHeight,
					&data.cyBottomHeight
				) == 5
			)
			{
				swscanf_s(
					keyBuffer,
					L"%d;%d;%d",
					&part.cxLeftWidth,
					&part.cxRightWidth,
					&part.cyTopHeight
				);

				if (g_themeAtlasLayoutQuirk == CompatibilityQuirk::RS1)
				{
					part.cxLeftWidth = part.cxLeftWidth > 10 ? part.cxLeftWidth - 1 : part.cxLeftWidth;
				}
				g_themeAtlasLayoutMap.try_emplace(
					make_theme_atlas_layout_key(
						part.cxLeftWidth,
						part.cxRightWidth,
						part.cyTopHeight
					),
					data
				);
			}
			else if (
				DWORD value{};
				swscanf_s(
					strideBuffer,
					L"%[^=]=%d",
					keyBuffer,
					static_cast<unsigned int>(std::size(keyBuffer)),
					&value
				) == 2
			)
			{
				if (!wcscmp(keyBuffer, L"DontDeflateInactiveFrameGeometry"))
				{
					Shared::g_dontDeflateInactiveFrameGeometry = static_cast<bool>(value);
				}
				else if (!wcscmp(keyBuffer, L"RS1Compatibility"))
				{
					g_themeAtlasLayoutQuirk = value ? CompatibilityQuirk::RS1 : g_themeAtlasLayoutQuirk;
				}
				else if (!wcscmp(keyBuffer, L"CaptionHeight"))
				{
					Shared::g_captionHeight = value;
				}
			}
		}
	}
	fclose(file);
}

HRESULT CustomThemeAtlasLoader::LoadTextGlowFromThemeAtlas()
{
	RECT textGlowAtlasRect{};
	RETURN_IF_FAILED(
		MyGetThemeRect(
			g_themeHandle.get(),
			static_cast<int>(DWM_WINDOW_THEME_PART::TEXTGLOW),
			0,
			TMT_ATLASRECT,
			&textGlowAtlasRect
		)
	);
	RETURN_IF_WIN32_BOOL_FALSE(InflateRect(&textGlowAtlasRect, -1, -1));
	winrt::com_ptr<IStream> stream{ SHCreateMemStream(g_themeAtlasStream.get(), g_themeAtlasStreamSize), winrt::take_ownership_from_abi };
	RETURN_HR_IF_NULL(E_OUTOFMEMORY, stream);
	winrt::com_ptr<IWICImagingFactory> wicFactory{ nullptr };
	wicFactory.copy_from(uDWM::CDesktopManager::GetInstance()->GetWICFactory());
	winrt::com_ptr<IWICBitmapDecoder> wicDecoder{ nullptr };
	RETURN_IF_FAILED(
		wicFactory->CreateDecoderFromStream(
			stream.get(),
			&GUID_VendorMicrosoft,
			WICDecodeMetadataCacheOnDemand,
			wicDecoder.put()
		)
	);
	winrt::com_ptr<IWICBitmapFrameDecode> wicFrame{ nullptr };
	RETURN_IF_FAILED(wicDecoder->GetFrame(0, wicFrame.put()));
	winrt::com_ptr<IWICFormatConverter> wicConverter{ nullptr };
	RETURN_IF_FAILED(wicFactory->CreateFormatConverter(wicConverter.put()));
	RETURN_IF_FAILED(
		wicConverter->Initialize(
			wicFrame.get(),
			GUID_WICPixelFormat32bppPBGRA,
			WICBitmapDitherTypeNone,
			nullptr,
			0,
			WICBitmapPaletteTypeCustom
		)
	);

	Shared::g_textGlowBitmapInfo =
	{
		{
			sizeof(Shared::g_textGlowBitmapInfo.bmiHeader),
			wil::rect_width(textGlowAtlasRect),
			-wil::rect_height(textGlowAtlasRect),
			1,
			32,
			BI_RGB
		}
	};
	Shared::g_textGlowBitmap.reset(
		CreateDIBSection(
			nullptr,
			&Shared::g_textGlowBitmapInfo,
			DIB_RGB_COLORS,
			&Shared::g_textGlowBitmapPixels,
			nullptr,
			0
		)
	);
	RETURN_LAST_ERROR_IF_NULL(Shared::g_textGlowBitmap);

	WICRect copyRect{ textGlowAtlasRect.left, textGlowAtlasRect.top, Shared::g_textGlowBitmapInfo.bmiHeader.biWidth, -Shared::g_textGlowBitmapInfo.bmiHeader.biHeight };
	RETURN_IF_FAILED(
		wicConverter->CopyPixels(
			&copyRect,
			Shared::g_textGlowBitmapInfo.bmiHeader.biWidth * 4,
			Shared::g_textGlowBitmapInfo.bmiHeader.biWidth * std::abs(Shared::g_textGlowBitmapInfo.bmiHeader.biHeight) * 4,
			reinterpret_cast<BYTE*>(Shared::g_textGlowBitmapPixels)
		)
	);

	return S_OK;
}

// windows 7 read the frame highlights from DWMWindow LEFTHIGHLIGHTCORNER (34) and SIDEHIGHLIGHT (43):
// the atlas rect cut into 2 vertical tiles (active, inactive), OPACITY on the corner and the side and
// SIZINGMARGINS on the side (uDWM 6.1.7762 CTopLevelWindow::GetNCAreaHelper / CreateBitmapsFromAtlasImageStrip).
// corner states 3/4 are taken as maximized/inactive maximized, the same mapping the reflection opacity uses.
// win10 gave 34/43 to other parts, so imported themes carry them as 95/96; LEFTHIGHLIGHTCORNERid / SIDEHIGHLIGHTid
// override that. uDWM also shaved 1px off every tile, but the win7 art this renderer was tuned with is
// the full tile, so the tiles stay whole here too.
static HRESULT CopyHighlightStrip(
	HTHEME theme,
	IWICBitmapSource* atlas,
	int partId,
	Shared::HighlightStrip& strip
)
{
	RECT rect{};
	RETURN_IF_FAILED(CustomThemeAtlasLoader::MyGetThemeRect(theme, partId, 0, TMT_ATLASRECT, &rect));
	UINT atlasWidth{}, atlasHeight{};
	RETURN_IF_FAILED(atlas->GetSize(&atlasWidth, &atlasHeight));
	const auto width = wil::rect_width(rect);
	const auto frameHeight = wil::rect_height(rect) / 2;
	RETURN_HR_IF(
		E_INVALIDARG,
		rect.left < 0 || rect.top < 0 || width <= 0 || frameHeight <= 0 ||
		static_cast<UINT>(rect.right) > atlasWidth || static_cast<UINT>(rect.bottom) > atlasHeight
	);

	strip.width = static_cast<UINT>(width);
	strip.frameHeight = static_cast<UINT>(frameHeight);
	strip.pixels.resize(static_cast<size_t>(strip.width) * strip.frameHeight * 2 * 4);
	const WICRect copyRect{ rect.left, rect.top, width, frameHeight * 2 };
	RETURN_IF_FAILED(atlas->CopyPixels(&copyRect, strip.width * 4, static_cast<UINT>(strip.pixels.size()), strip.pixels.data()));
	return S_OK;
}

void CustomThemeAtlasLoader::LoadHighlights()
{
	const auto style = static_cast<Shared::HighlightStyle>(std::clamp(GlassEngine::GetDwordFromRegistry(L"HighlightStyle", 0), 0ul, 2ul));
	Shared::g_highlightStyle = style;

	// windows 7 numbers, what this renderer always used. vista hides the corners on maximized windows.
	Shared::g_highlightOpacity = style == Shared::HighlightStyle::WindowsVista ?
		std::array<float, 4>{ .75f, .75f, 0.f, 0.f } :
		std::array<float, 4>{ .75f, .75f, .75f, .75f };
	Shared::g_sideHighlightOpacity = { 1.f, .5f };
	Shared::g_sideHighlightSizingMargin = 2;
	Shared::g_themeHighlightAssets.store(nullptr);

	if (style == Shared::HighlightStyle::Msstyles && g_themeHandle && g_themeAtlasStreamSize)
	{
		const auto cornerId = static_cast<int>(GlassEngine::GetDwordFromRegistry(L"LEFTHIGHLIGHTCORNERid", 95));
		const auto sideId = static_cast<int>(GlassEngine::GetDwordFromRegistry(L"SIDEHIGHLIGHTid", 96));
		auto assets = std::make_shared<Shared::HighlightAssets>();

		const auto loadFromAtlas = [&]() -> HRESULT
		{
			winrt::com_ptr<IStream> stream{ SHCreateMemStream(g_themeAtlasStream.get(), g_themeAtlasStreamSize), winrt::take_ownership_from_abi };
			RETURN_HR_IF_NULL(E_OUTOFMEMORY, stream);
			winrt::com_ptr<IWICImagingFactory> wicFactory{ nullptr };
			wicFactory.copy_from(uDWM::CDesktopManager::GetInstance()->GetWICFactory());
			winrt::com_ptr<IWICBitmapDecoder> wicDecoder{ nullptr };
			RETURN_IF_FAILED(wicFactory->CreateDecoderFromStream(stream.get(), &GUID_VendorMicrosoft, WICDecodeMetadataCacheOnDemand, wicDecoder.put()));
			winrt::com_ptr<IWICBitmapFrameDecode> wicFrame{ nullptr };
			RETURN_IF_FAILED(wicDecoder->GetFrame(0, wicFrame.put()));
			winrt::com_ptr<IWICFormatConverter> wicConverter{ nullptr };
			RETURN_IF_FAILED(wicFactory->CreateFormatConverter(wicConverter.put()));
			RETURN_IF_FAILED(wicConverter->Initialize(wicFrame.get(), GUID_WICPixelFormat32bppPBGRA, WICBitmapDitherTypeNone, nullptr, 0, WICBitmapPaletteTypeCustom));

			// a missing or broken part only loses that part: it keeps the windows 7 art and numbers.
			if (FAILED(CopyHighlightStrip(g_themeHandle.get(), wicConverter.get(), cornerId, assets->corner)))
			{
				assets->corner = {};
			}
			else
			{
				for (int state = 1; state <= 4; state++)
				{
					int opacity{};
					if (SUCCEEDED(MyGetThemeInt(g_themeHandle.get(), cornerId, state, TMT_OPACITY, &opacity)))
					{
						Shared::g_highlightOpacity[state - 1] = std::clamp(static_cast<float>(opacity) / 100.f, 0.f, 1.f);
					}
				}
			}

			if (FAILED(CopyHighlightStrip(g_themeHandle.get(), wicConverter.get(), sideId, assets->side)))
			{
				assets->side = {};
			}
			else
			{
				for (int state = 1; state <= 2; state++)
				{
					int opacity{};
					if (SUCCEEDED(MyGetThemeInt(g_themeHandle.get(), sideId, state, TMT_OPACITY, &opacity)))
					{
						Shared::g_sideHighlightOpacity[state - 1] = std::clamp(static_cast<float>(opacity) / 100.f, 0.f, 1.f);
					}
				}
				MARGINS margins{};
				if (SUCCEEDED(MyGetThemeMargins(g_themeHandle.get(), nullptr, sideId, 0, TMT_SIZINGMARGINS, nullptr, &margins)))
				{
					Shared::g_sideHighlightSizingMargin = std::clamp(margins.cyBottomHeight, 0, static_cast<int>(assets->side.frameHeight));
				}
			}
			return S_OK;
		};
		LOG_IF_FAILED(loadFromAtlas());

		if (!assets->corner.pixels.empty() || !assets->side.pixels.empty())
		{
			Shared::g_themeHighlightAssets.store(std::move(assets));
		}
	}

	Shared::g_highlightGeneration++;
}

void CustomThemeAtlasLoader::LoadTheme(LPCWSTR themeAtlasPath, LPCWSTR themeAtlasLayoutPath)
{
	g_themeHandle.reset(OpenThemeData(nullptr, L"DWMWindow"));

	if (SUCCEEDED(LoadThemeAtlas(themeAtlasPath)))
	{
		LoadThemeAtlasLayout(themeAtlasLayoutPath);
		LoadTextGlowFromThemeAtlas();
	}
}

void CustomThemeAtlasLoader::Update(GlassEngine::UpdateType type)
{
	if (type & GlassEngine::UpdateType::Theme)
	{
		WCHAR themeAtlasPath[MAX_PATH]{}, themeAtlasLayoutPath[MAX_PATH]{};
		GlassEngine::GetStringFromRegistry(
			L"CustomThemeAtlas",
			themeAtlasPath
		);
		PathUnquoteSpacesW(themeAtlasPath);
		wcscpy_s(themeAtlasLayoutPath, themeAtlasPath);
		wcscat_s(themeAtlasLayoutPath, L".layout");

		UnloadTheme();
		LoadTheme(
			themeAtlasPath,
			themeAtlasLayoutPath
		);
		LoadHighlights();
	}
	if (type & GlassEngine::UpdateType::Backdrop || type & GlassEngine::UpdateType::Theme)
	{
		DWORD active = 0, inactive = 0, maximized = 0, inactiveMaximized = 0, transparent = 0, opaque = 0;
		const auto themeHandle = CustomThemeAtlasLoader::GetThemeHandle();

		active = GlassEngine::GetDwordFromRegistry(L"ColorizationGlassReflectionOpacity", 0xFFFFFFFE);
		inactive = GlassEngine::GetDwordFromRegistry(L"ColorizationGlassReflectionOpacityInactive", active);
		maximized = GlassEngine::GetDwordFromRegistry(L"ColorizationGlassReflectionOpacityMaximized", active);
		inactiveMaximized = GlassEngine::GetDwordFromRegistry(L"ColorizationGlassReflectionOpacityInactiveMaximized", inactive);

		if (active == 0xFFFFFFFE)
		{
			if (Shared::g_type == Shared::GlassType::Blur)
			{
				active = 90;
			}
			else if (Shared::g_type == Shared::GlassType::Aero)
			{
				active = 90;
			}
		}
		else if (active == 0xFFFFFFFF)
		{
			if (themeHandle)
			{
				active = 90;
				CustomThemeAtlasLoader::MyGetThemeInt(themeHandle, static_cast<int>(DWM_WINDOW_THEME_PART::SQUEEGEREFLECTIONMAP), 1, TMT_OPACITY, reinterpret_cast<int*>(&active));
			}
		}
		if (inactive == 0xFFFFFFFE)
		{
			if (Shared::g_type == Shared::GlassType::Blur)
			{
				inactive = 40;
			}
			else if (Shared::g_type == Shared::GlassType::Aero)
			{
				inactive = 75;
			}
		}
		else if (inactive == 0xFFFFFFFF)
		{
			if (themeHandle)
			{
				inactive = 75;
				CustomThemeAtlasLoader::MyGetThemeInt(themeHandle, static_cast<int>(DWM_WINDOW_THEME_PART::SQUEEGEREFLECTIONMAP), 2, TMT_OPACITY, reinterpret_cast<int*>(&inactive));
			}
		}
		if (maximized == 0xFFFFFFFE)
		{
			if (Shared::g_type == Shared::GlassType::Blur)
			{
				maximized = 50;
			}
			else if (Shared::g_type == Shared::GlassType::Aero)
			{
				maximized = 90;
			}
		}
		else if (maximized == 0xFFFFFFFF)
		{
			if (themeHandle)
			{
				maximized = 90;
				CustomThemeAtlasLoader::MyGetThemeInt(themeHandle, static_cast<int>(DWM_WINDOW_THEME_PART::SQUEEGEREFLECTIONMAP), 3, TMT_OPACITY, reinterpret_cast<int*>(&maximized));
			}
		}
		if (inactiveMaximized == 0xFFFFFFFE)
		{
			if (Shared::g_type == Shared::GlassType::Blur)
			{
				inactiveMaximized = 20;
			}
			else if (Shared::g_type == Shared::GlassType::Aero)
			{
				inactiveMaximized = 75;
			}
		}
		else if (inactiveMaximized == 0xFFFFFFFF)
		{
			if (themeHandle)
			{
				inactiveMaximized = 75;
				CustomThemeAtlasLoader::MyGetThemeInt(themeHandle, static_cast<int>(DWM_WINDOW_THEME_PART::SQUEEGEREFLECTIONMAP), 4, TMT_OPACITY, reinterpret_cast<int*>(&inactiveMaximized));
			}
		}

		Shared::g_reflectionOpacity = std::clamp(static_cast<float>(active) / 100.f, 0.f, 1.f);
		Shared::g_reflectionOpacityInactive = std::clamp(static_cast<float>(inactive) / 100.f, 0.f, 1.f);
		Shared::g_reflectionOpacityMaximized = std::clamp(static_cast<float>(maximized) / 100.f, 0.f, 1.f);
		Shared::g_reflectionOpacityInactiveMaximized = std::clamp(static_cast<float>(inactiveMaximized) / 100.f, 0.f, 1.f);

		active = 0, inactive = 0, maximized = 0, inactiveMaximized = 0;
		active = GlassEngine::GetDwordFromRegistry(L"ColorizationOpacity", 0xFFFFFFFE);
		inactive = GlassEngine::GetDwordFromRegistry(L"ColorizationOpacityInactive", active);
		maximized = GlassEngine::GetDwordFromRegistry(L"ColorizationOpacityMaximized", active);
		inactiveMaximized = GlassEngine::GetDwordFromRegistry(L"ColorizationOpacityInactiveMaximized", inactive);

		if (active == 0xFFFFFFFE)
		{
			if (Shared::g_type == Shared::GlassType::Blur)
			{
				active = 100;
			}
			else if (Shared::g_type == Shared::GlassType::Aero)
			{
				active = 100;
			}
		}
		else if (active == 0xFFFFFFFF)
		{
			if (themeHandle)
			{
				active = 100;
				CustomThemeAtlasLoader::MyGetThemeInt(themeHandle, static_cast<int>(DWM_WINDOW_THEME_PART::TOPFRAME), 1, TMT_COLORIZATIONOPACITY, reinterpret_cast<int*>(&active));
			}
		}
		if (inactive == 0xFFFFFFFE)
		{
			if (Shared::g_type == Shared::GlassType::Blur)
			{
				inactive = 55;
			}
			else if (Shared::g_type == Shared::GlassType::Aero)
			{
				inactive = 40;
			}
		}
		else if (inactive == 0xFFFFFFFF)
		{
			if (themeHandle)
			{
				inactive = 40;
				CustomThemeAtlasLoader::MyGetThemeInt(themeHandle, static_cast<int>(DWM_WINDOW_THEME_PART::TOPFRAME), 2, TMT_COLORIZATIONOPACITY, reinterpret_cast<int*>(&inactive));
			}
		}
		if (maximized == 0xFFFFFFFE)
		{
			if (Shared::g_type == Shared::GlassType::Blur)
			{
				maximized = 75;
			}
			else if (Shared::g_type == Shared::GlassType::Aero)
			{
				maximized = 100;
			}
		}
		else if (maximized == 0xFFFFFFFF)
		{
			if (themeHandle)
			{
				maximized = 100;
				CustomThemeAtlasLoader::MyGetThemeInt(themeHandle, static_cast<int>(DWM_WINDOW_THEME_PART::TOPFRAME), 3, TMT_COLORIZATIONOPACITY, reinterpret_cast<int*>(&maximized));
			}
		}
		if (inactiveMaximized == 0xFFFFFFFE)
		{
			if (Shared::g_type == Shared::GlassType::Blur)
			{
				inactiveMaximized = 75;
			}
			else if (Shared::g_type == Shared::GlassType::Aero)
			{
				inactiveMaximized = 40;
			}
		}
		else if (inactiveMaximized == 0xFFFFFFFF)
		{
			if (themeHandle)
			{
				inactiveMaximized = 40;
				CustomThemeAtlasLoader::MyGetThemeInt(themeHandle, static_cast<int>(DWM_WINDOW_THEME_PART::TOPFRAME), 4, TMT_COLORIZATIONOPACITY, reinterpret_cast<int*>(&inactiveMaximized));
			}
		}

		Shared::g_colorizationOpacity = std::clamp(static_cast<float>(active) / 100.f, 0.f, 1.f);
		Shared::g_colorizationOpacityInactive = std::clamp(static_cast<float>(inactive) / 100.f, 0.f, 1.f);
		Shared::g_colorizationOpacityMaximized = std::clamp(static_cast<float>(maximized) / 100.f, 0.f, 1.f);
		Shared::g_colorizationOpacityInactiveMaximized = std::clamp(static_cast<float>(inactiveMaximized) / 100.f, 0.f, 1.f);

		active = 0, inactive = 0, maximized = 0, inactiveMaximized = 0;
		transparent = GlassEngine::GetDwordFromRegistry(L"ColorizationBaseTransparent", 0xFFFFFFFE);
		maximized = GlassEngine::GetDwordFromRegistry(L"ColorizationBaseMaximized", 0xFFFFFFFE);
		opaque = GlassEngine::GetDwordFromRegistry(L"ColorizationBaseOpaque", 0xFFFFFFFE);

		if (transparent == 0xFFFFFFFE)
		{
			if (Shared::g_type == Shared::GlassType::Blur)
			{
				transparent = 0x00000000;
			}
			else if (Shared::g_type == Shared::GlassType::Aero)
			{
				transparent = 0x00000000;
			}
		}
		else if (transparent == 0xFFFFFFFF)
		{
			if (themeHandle)
			{
				transparent = 0x00000000;
				CustomThemeAtlasLoader::MyGetThemeInt(themeHandle, static_cast<int>(DWM_WINDOW_THEME_PART::TOPFRAME), 1, TMT_COLORIZATIONCOLOR, reinterpret_cast<int*>(&transparent));
			}
		}
		if (maximized == 0xFFFFFFFE)
		{
			if (Shared::g_type == Shared::GlassType::Blur)
			{
				maximized = 0xFF000000;
			}
			else if (Shared::g_type == Shared::GlassType::Aero)
			{
				maximized = 0x00000000;
			}
		}
		else if (maximized == 0xFFFFFFFF)
		{
			if (themeHandle)
			{
				maximized = 0x00000000;
				CustomThemeAtlasLoader::MyGetThemeInt(themeHandle, static_cast<int>(DWM_WINDOW_THEME_PART::TOPFRAME), 3, TMT_COLORIZATIONCOLOR, reinterpret_cast<int*>(&maximized));
			}
		}
		if (opaque == 0xFFFFFFFE)
		{
			if (Shared::g_type == Shared::GlassType::Blur)
			{
				opaque = 0xFFDFDFDF;
			}
			else if (Shared::g_type == Shared::GlassType::Aero)
			{
				opaque = 0xFFDFDFDF;
			}
		}
		else if (opaque == 0xFFFFFFFF)
		{
			if (themeHandle)
			{
				opaque = 0xFFDFDFDF;
				CustomThemeAtlasLoader::MyGetThemeInt(themeHandle, static_cast<int>(DWM_WINDOW_THEME_PART::COMMON), 0, TMT_COLORIZATIONCOLOR, reinterpret_cast<int*>(&opaque));
			}
		}

		Shared::g_colorizationBaseTransparent = Color::FromArgb(transparent, false);
		Shared::g_colorizationBaseMaximized = Color::FromArgb(maximized, false);
		Shared::g_colorizationBaseOpaque = Color::FromArgb(opaque, false);
	}
}

void CustomThemeAtlasLoader::Startup()
{
	const auto build_before_w10_2004 = uDWM::g_versionInfo.build < os::build_w10_2004;
	HookHelper::PatchDelayloadIAT(
		uDWM::g_moduleHandle,
		std::initializer_list<HookHelper::ImportDllDetourInfo>
		{
			{
				"ext-ms-win-uxtheme-themes-l1-1-0.dll",
				std::initializer_list<HookHelper::ImportFunctionDetourInfo>
				{
					{ "GetThemeMargins", &g_GetThemeMargins_Org, &MyGetThemeMargins },
					{ "GetThemeInt", &g_GetThemeInt_Org, &MyGetThemeInt },
					{ "GetThemeColor", &g_GetThemeColor_Org, &MyGetThemeColor }
				}
			},
			{
				build_before_w10_2004 ? "UxTheme.dll" : "ext-ms-win-uxtheme-themes-l1-1-2.dll",
				std::initializer_list<HookHelper::ImportFunctionDetourInfo>
				{
					{ "GetThemeStream", &g_GetThemeStream_Org, &MyGetThemeStream },
					{ "GetThemeRect", &g_GetThemeRect_Org, &MyGetThemeRect }
				}
			}
		}
	);

	PostMessageW(FindWindowW(L"DWM", nullptr), WM_THEMECHANGED, 0, 0);
}
void CustomThemeAtlasLoader::Shutdown()
{
	const auto build_before_w10_2004 = uDWM::g_versionInfo.build < os::build_w10_2004;
	HookHelper::PatchDelayloadIAT(
		uDWM::g_moduleHandle,
		std::initializer_list<HookHelper::ImportDllDetourInfo>
		{
			{
				"ext-ms-win-uxtheme-themes-l1-1-0.dll",
				std::initializer_list<HookHelper::ImportFunctionDetourInfo>
				{
					{ "GetThemeMargins", &g_GetThemeMargins_Org, g_GetThemeMargins_Org },
					{ "GetThemeInt", &g_GetThemeInt_Org, g_GetThemeInt_Org },
					{ "GetThemeColor", &g_GetThemeColor_Org, g_GetThemeColor_Org }
				}
			},
			{
				build_before_w10_2004 ? "UxTheme.dll" : "ext-ms-win-uxtheme-themes-l1-1-2.dll",
				std::initializer_list<HookHelper::ImportFunctionDetourInfo>
				{
					{ "GetThemeStream", &g_GetThemeStream_Org, g_GetThemeStream_Org },
					{ "GetThemeRect", &g_GetThemeRect_Org, g_GetThemeRect_Org }
				}
			}
		}
	);

	SendMessageW(FindWindowW(L"DWM", nullptr), WM_THEMECHANGED, 0, 0);

	UnloadTheme();
}
