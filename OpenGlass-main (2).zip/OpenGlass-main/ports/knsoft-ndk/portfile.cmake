vcpkg_from_github(
    OUT_SOURCE_PATH SOURCE_PATH
    REPO KNSoft/KNSoft.NDK
    REF 28323bec24116c3aadbebc1c8424acb29c4de559
    SHA512 14866fccfd945af485cce5e96f8eba612da7c9495e55c18bd814b7470fdbe33dcde783d77d83c1856537d7b4df15307742c3f09d0fb1c28dff6eb04d6c31249f
)

set(CONSOLE_INCLUDE_DIR "${SOURCE_PATH}/Source/Include/KNSoft/NDK/3rdParty/terminal/dep/Console")

set(CONIOSRV_HEADER "${CONSOLE_INCLUDE_DIR}/ConIoSrv.h")
file(READ "${CONIOSRV_HEADER}" CONIOSRV_CONTENTS)
string(REPLACE "#include <ntlpcapi.h>" "#include <KNSoft/NDK/Stub/ntlpcapi.h>" CONIOSRV_CONTENTS "${CONIOSRV_CONTENTS}")
file(WRITE "${CONIOSRV_HEADER}" "${CONIOSRV_CONTENTS}")

set(CONMSGL3_HEADER "${CONSOLE_INCLUDE_DIR}/conmsgl3.h")
file(READ "${CONMSGL3_HEADER}" CONMSGL3_CONTENTS)
string(REPLACE "#include <winconp.h>" "#include <KNSoft/NDK/3rdParty/terminal/dep/Console/winconp.h>" CONMSGL3_CONTENTS "${CONMSGL3_CONTENTS}")
file(WRITE "${CONMSGL3_HEADER}" "${CONMSGL3_CONTENTS}")

file(INSTALL "${SOURCE_PATH}/Source/Include/" DESTINATION "${CURRENT_PACKAGES_DIR}/include")

file(INSTALL "${SOURCE_PATH}/LICENSE" DESTINATION "${CURRENT_PACKAGES_DIR}/share/knsoft-ndk" RENAME copyright)
