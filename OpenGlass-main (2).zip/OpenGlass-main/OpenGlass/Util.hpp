#pragma once
#include "framework.hpp"
#include "cpprt.hpp"
#include "wil.hpp"
#include "HookHelper.hpp"
#include "DxgiPrivates.hpp"
#include "RectF.hpp"
#include <winrt/windows.ui.h>

namespace OpenGlass::Util
{
	inline const auto g_processHeap = GetProcessHeap();
	inline const auto g_thisModulePath = wil::GetModuleFileNameW<std::wstring, MAX_PATH>(wil::GetModuleInstanceHandle());

	using unique_rouninitialize_call = wil::unique_call<decltype(&::RoUninitialize), ::RoUninitialize>;

	template <typename T>
	class ComRefCounted
	{
	public:
		ComRefCounted() noexcept = default;

		ULONG AddRef() noexcept
		{
			return static_cast<ULONG>(InterlockedIncrement(&m_referenceCount));
		}

		ULONG Release() noexcept
		{
			const auto referenceCount = InterlockedDecrement(&m_referenceCount);
			if (!referenceCount)
			{
				delete static_cast<T*>(this);
			}
			return static_cast<ULONG>(referenceCount);
		}

	protected:
		~ComRefCounted() = default;

	private:
		ComRefCounted(const ComRefCounted&) = delete;
		ComRefCounted& operator=(const ComRefCounted&) = delete;

		LONG m_referenceCount{ 1 };
	};

	template <typename T, typename... Args>
	winrt::com_ptr<T> make_com_ptr(Args&&... args)
	{
		static_assert(std::is_base_of_v<ComRefCounted<T>, T>);
		return { new T(std::forward<Args>(args)...), winrt::take_ownership_from_abi };
	}

	// ptr to complex
	template <typename T>
	FORCEINLINE constexpr auto force_cast_to(PVOID ptr)
	{
		T target_ptr{ nullptr };
		*reinterpret_cast<PVOID*>(&target_ptr) = ptr;
		return target_ptr;
	}
	// complex to ptr
	template <typename T>
	FORCEINLINE constexpr PVOID force_cast_from(T ptr)
	{
		return *reinterpret_cast<PVOID*>(&ptr);
	}

	struct VersionInfo
	{
		ULONG build;
		ULONG revision;
	};

	template <ULONG build, ULONG revision>
	FORCEINLINE constexpr bool VersionBefore(
		ULONG runtimeBuild,
		ULONG runtimeRevision
	)
	{
		if constexpr (!build)
		{
			return true;
		}
		if constexpr (!revision)
		{
			return runtimeBuild < build;
		}
		return runtimeBuild < build ||
			(runtimeBuild == build && runtimeRevision < revision);
	}

	template <UINT id>
	FORCEINLINE const auto GetResourceStringView()
	{
		LPCWSTR buffer{ nullptr };
		auto length = LoadStringW(wil::GetModuleInstanceHandle(), id, reinterpret_cast<LPWSTR>(&buffer), 0);
		return std::wstring_view{ buffer, static_cast<size_t>(length) };
	}
	template <UINT id>
	FORCEINLINE std::wstring GetResourceString()
	{
		return std::wstring{ GetResourceStringView<id>() };
	}

	inline HRESULT GetResDataView(std::span<const UCHAR>& resourceView, UINT id, HMODULE moduleHandle = wil::GetModuleInstanceHandle(), LPCWSTR type = RT_RCDATA)
	{
		const auto resourceHandle = FindResourceW(moduleHandle, MAKEINTRESOURCE(id), type);
		RETURN_LAST_ERROR_IF_NULL(resourceHandle);
		const auto globalHandle = LoadResource(moduleHandle, resourceHandle);
		RETURN_LAST_ERROR_IF_NULL(globalHandle);
		const auto resourceAddress = reinterpret_cast<PBYTE>(LockResource(globalHandle));
		RETURN_LAST_ERROR_IF_NULL(resourceAddress);
		const auto resourceSize = SizeofResource(moduleHandle, resourceHandle);
		RETURN_LAST_ERROR_IF(resourceSize == 0);
		resourceView = { resourceAddress, resourceSize };

		return S_OK;
	}

	inline HRESULT MB2WC(std::unique_ptr<WCHAR[]>& buffer, LPCSTR str, int size = -1, int* outLength = nullptr)
	{
		auto length = MultiByteToWideChar(CP_ACP, 0, str, size, nullptr, 0);
		RETURN_LAST_ERROR_IF(length == 0);
		buffer.reset(new WCHAR[length]);
		RETURN_LAST_ERROR_IF_NULL(buffer);
		length = MultiByteToWideChar(CP_ACP, 0, str, size, buffer.get(), length);
		RETURN_LAST_ERROR_IF(length == 0);
		if (outLength) { *outLength = length; }
		return S_OK;
	}
	inline HRESULT WC2MB(std::unique_ptr<CHAR[]>& buffer, LPCWSTR str, int size = -1, int* outLength = nullptr)
	{
		auto length = WideCharToMultiByte(CP_UTF8, 0, str, size, nullptr, 0, nullptr, nullptr);
		RETURN_LAST_ERROR_IF(length == 0);
		buffer.reset(new CHAR[length]);
		RETURN_LAST_ERROR_IF_NULL(buffer);
		length = WideCharToMultiByte(CP_UTF8, 0, str, size, buffer.get(), length, nullptr, nullptr);
		RETURN_LAST_ERROR_IF(length == 0);
		if (outLength) { *outLength = length; }
		return S_OK;
	}

	// type = 1, input desktop (grpdeskRitInput)
	// type = 2, default desktop? (grpdeskIODefault)
	// type = 3, unknown
	// type = 4, winlogon desktop (grpdeskLogon)
	// type = ..., desktop created by CreateDesktop?
	FORCEINLINE bool WINAPI GetDesktopID(ULONG_PTR type, ULONG_PTR* desktopID)
	{
		static const auto sc_pfnGetDesktopID = reinterpret_cast<decltype(&GetDesktopID)>(GetProcAddress(GetModuleHandleW(L"user32.dll"), "GetDesktopID"));
		if (sc_pfnGetDesktopID) [[likely]]
		{
			return sc_pfnGetDesktopID(type, desktopID);
		}

		return false;
	}

	FORCEINLINE bool WINAPI IsRunAsLocalSystem()
	{
		BOOL isLocalSystem{ FALSE };
		wil::unique_sid sid{ nullptr };
		SID_IDENTIFIER_AUTHORITY authority{ SECURITY_NT_AUTHORITY };
		if (AllocateAndInitializeSid(&authority, 1ul, SECURITY_LOCAL_SYSTEM_RID, 0, 0, 0, 0, 0, 0, 0, &sid))
		{
			CheckTokenMembership(0, sid.get(), &isLocalSystem);
		}
		return static_cast<bool>(isLocalSystem);
	}

	inline HRESULT WINAPI TaskDialog(
		_In_opt_ HWND hwndOwner,
		_In_opt_ HINSTANCE hInstance,
		_In_opt_ PCWSTR pszWindowTitle,
		_In_opt_ PCWSTR pszMainInstruction,
		_In_opt_ PCWSTR pszContent,
		TASKDIALOG_COMMON_BUTTON_FLAGS dwCommonButtons, 
		_In_opt_ PCWSTR pszIcon,
		_Out_opt_ int* pnButton
	)
	{
		TASKDIALOGCONFIG config
		{ 
			sizeof(TASKDIALOGCONFIG), 
			hwndOwner, 
			hInstance,
			TDF_SIZE_TO_CONTENT | TDF_ALLOW_DIALOG_CANCELLATION,
			dwCommonButtons,
			pszWindowTitle,
			{ .pszMainIcon{ pszIcon } },
			pszMainInstruction,
			pszContent,
			0, 
			nullptr, 
			0, 
			0, 
			nullptr, 
			0, 
			nullptr, 
			nullptr, 
			nullptr, 
			nullptr, 
			{}, 
			nullptr, 
			nullptr, 
			0, 
			0 
		};
		return TaskDialogIndirect(
			&config,
			pnButton,
			nullptr,
			nullptr
		);
	}

	inline VersionInfo GetModuleVersionInfo(HMODULE moduleHandle)
	{
		const auto moduleName = wil::GetModuleFileNameW<std::wstring, MAX_PATH>(moduleHandle);

		DWORD size{ GetFileVersionInfoSizeW(moduleName.c_str(), nullptr)};
		THROW_LAST_ERROR_IF(!size);

		auto data{ std::make_unique_for_overwrite<BYTE[]>(size) };
		#pragma warning(suppress : 6388)
		THROW_LAST_ERROR_IF(!GetFileVersionInfoW(moduleName.c_str(), 0, size, data.get()));

		UINT len{ 0 };
		VS_FIXEDFILEINFO* fileInfo{ nullptr };
		THROW_IF_WIN32_BOOL_FALSE(VerQueryValueW(data.get(), L"\\", reinterpret_cast<PVOID*>(&fileInfo), &len));
		THROW_LAST_ERROR_IF(!len);

		THROW_WIN32_IF(ERROR_INVALID_IMAGE_HASH, fileInfo->dwSignature != VS_FFI_SIGNATURE);

		return { HIWORD(fileInfo->dwFileVersionLS), LOWORD(fileInfo->dwFileVersionLS) };
	}

	inline HRESULT GetSwapchainFromTexure(
		ID3D11Texture2D* texture,
		winrt::com_ptr<IDXGISwapChain1>& dxgiSwapChain
	)
	{
		winrt::com_ptr<IDXGIResource> dxgiResource;
		RETURN_IF_FAILED(texture->QueryInterface(dxgiResource.put()));
		return dxgiResource->GetParent(IID_PPV_ARGS(dxgiSwapChain.put()));
	}

	inline HRESULT GetDescAndHwProtectionStateFromTexture(
		ID3D11Texture2D* texture,
		D3D11_TEXTURE2D_DESC& textureDesc,
		BOOL& hwProtectionEnabled
	)
	{
		texture->GetDesc(&textureDesc);

		if ((textureDesc.MiscFlags & D3D11_RESOURCE_MISC_HW_PROTECTED) == D3D11_RESOURCE_MISC_HW_PROTECTED)
		{
			hwProtectionEnabled = TRUE;
		}
		else
		{
			winrt::com_ptr<IDXGISwapChain1> dxgiSwapChain{};
			if (SUCCEEDED(GetSwapchainFromTexure(texture, dxgiSwapChain)))
			{
				winrt::com_ptr<IDXGISwapChainDWM1> dxgiSwapchainDwm{};
				RETURN_IF_FAILED(dxgiSwapChain->QueryInterface(dxgiSwapchainDwm.put()));
				RETURN_IF_FAILED(dxgiSwapchainDwm->GetHardwareProtection(&hwProtectionEnabled));
			}
		}

		return S_OK;
	}

	inline HRESULT GetTextureFromD2DBitmap(
		ID2D1Bitmap1* bitmap,
		winrt::com_ptr<ID3D11Texture2D>& texture,
		UINT* subresource = nullptr
	)
	{
		winrt::com_ptr<IDXGISurface> dxgiSurface{};
		RETURN_IF_FAILED(bitmap->GetSurface(dxgiSurface.put()));
		winrt::com_ptr<IDXGISurface2> subresourceSurface;
		RETURN_IF_FAILED(dxgiSurface->QueryInterface(subresourceSurface.put()));
		// A subresource surface is a separate object. GetResource returns its parent texture.
		UINT index;
		RETURN_IF_FAILED(subresourceSurface->GetResource(IID_PPV_ARGS(texture.put()), &index));
		if (subresource)
		{
			*subresource = index;
		}
		return S_OK;
	}

	inline void CopyTextureRegion(
		ID3D11DeviceContext* context,
		ID3D11Texture2D* src,
		ID3D11Texture2D* dst,
		const D2D1_RECT_U& srcRect,
		UINT dstX,
		UINT dstY,
		UINT srcSubresource = 0,
		UINT dstSubresource = 0
	)
	{
		D3D11_BOX box{};
		box.left = srcRect.left;
		box.top = srcRect.top;
		box.right = srcRect.right;
		box.bottom = srcRect.bottom;
		box.front = 0;
		box.back = 1;
		context->CopySubresourceRegion(dst, dstSubresource, dstX, dstY, 0, src, srcSubresource, &box);
	}

	inline HRESULT GetTargetBitmapFromD2DContext(
		const ID2D1DeviceContext* context,
		winrt::com_ptr<ID2D1Bitmap1>& targetBitmap
	)
	{
		winrt::com_ptr<ID2D1Image> targetImage{ nullptr };
		context->GetTarget(targetImage.put());
		if (!targetImage)
		{
			return E_FAIL;
		}

		RETURN_IF_FAILED(targetImage->QueryInterface(targetBitmap.put()));
		return S_OK;
	}

	inline HRESULT DrawNineGridBitmap(
		ID2D1DeviceContext* context,
		ID2D1Bitmap1* bitmap,
		const D2D1_RECT_F& destinationRect,
		const MARGINS& margins,
		float opacity
	)
	{
		const auto primitiveBlend = context->GetPrimitiveBlend();
		context->SetPrimitiveBlend(D2D1_PRIMITIVE_BLEND_COPY);
		context->PushAxisAlignedClip(destinationRect, D2D1_ANTIALIAS_MODE_ALIASED);
		const auto restoreBlendMode = wil::scope_exit([&] 
		{
			context->PopAxisAlignedClip();
			context->SetPrimitiveBlend(primitiveBlend);
		});

		const auto destinationWidth = wil::rect_width(destinationRect);
		const auto destinationHeight = wil::rect_height(destinationRect);

		if (destinationWidth <= 0.f || destinationHeight <= 0.f)
		{
			return S_OK; // Nothing to draw for non-positive destination size
		}

		const auto bitmapSize = bitmap->GetSize();

		// Source margin sizes from input MARGINS, converted to float
		// Assuming margins members (cxLeftWidth etc.) are non-negative as is typical.
		D2D1_RECT_F srcMargins
		{
			static_cast<float>(margins.cxLeftWidth),
			static_cast<float>(margins.cyTopHeight),
			static_cast<float>(margins.cxRightWidth),
			static_cast<float>(margins.cyBottomHeight)
		};

		// Source center part dimensions from bitmap
		const auto totalSrcHorizontalMargins = srcMargins.left + srcMargins.right;
		const auto totalSrcVerticalMargins = srcMargins.top + srcMargins.bottom;
		const auto srcCenterPartWidth = std::max(0.f, bitmapSize.width - totalSrcHorizontalMargins);
		const auto srcCenterPartHeight = std::max(0.f, bitmapSize.height - totalSrcVerticalMargins);

		// Initialize effective destination dimensions for margins and center parts
		D2D1_RECT_F destMargins = srcMargins;

		auto destCenterPartWidth = destinationWidth - totalSrcHorizontalMargins;
		auto destCenterPartHeight = destinationHeight - totalSrcVerticalMargins;

		// Adjust horizontal destination parts if calculated center width is negative
		if (destCenterPartWidth < 0.f)
		{
			destCenterPartWidth = 0.f; // Center part cannot be negative
			
			const auto ratio = destinationWidth / totalSrcHorizontalMargins;
			destMargins.left *= ratio;
			destMargins.left = std::floor(destMargins.left);
			destMargins.right = destinationWidth - destMargins.left;
		}

		// Adjust vertical destination parts if calculated center height is negative
		if (destCenterPartHeight < 0.f)
		{
			destCenterPartHeight = 0.f; // Center part cannot be negative

			const auto ratio = destinationHeight / totalSrcVerticalMargins;
			destMargins.top *= ratio;
			destMargins.top = std::floor(destMargins.top);
			destMargins.bottom = destinationHeight - destMargins.top;
		}

		// Top-Left
		context->DrawBitmap(
			bitmap,
			D2D1::RectF(destinationRect.left, destinationRect.top, destinationRect.left + destMargins.left, destinationRect.top + destMargins.top),
			opacity, D2D1_BITMAP_INTERPOLATION_MODE_LINEAR,
			D2D1::RectF(0.f, 0.f, srcMargins.left, srcMargins.top)
		);

		if (destCenterPartWidth)
		{
			// Top-Center
			context->DrawBitmap(
				bitmap,
				D2D1::RectF(destinationRect.left + destMargins.left, destinationRect.top, destinationRect.left + destMargins.left + destCenterPartWidth, destinationRect.top + destMargins.top),
				opacity, D2D1_BITMAP_INTERPOLATION_MODE_LINEAR,
				D2D1::RectF(srcMargins.left, 0.f, srcMargins.left + srcCenterPartWidth, srcMargins.top)
			);
		}

		// Top-Right
		context->DrawBitmap(
			bitmap,
			D2D1::RectF(destinationRect.right - destMargins.right, destinationRect.top, destinationRect.right, destinationRect.top + destMargins.top),
			opacity, D2D1_BITMAP_INTERPOLATION_MODE_LINEAR,
			D2D1::RectF(bitmapSize.width - srcMargins.right, 0.f, bitmapSize.width, srcMargins.top)
		);

		if (destCenterPartHeight)
		{
			// Middle-Left
			context->DrawBitmap(
				bitmap,
				D2D1::RectF(destinationRect.left, destinationRect.top + destMargins.top, destinationRect.left + destMargins.left, destinationRect.top + destMargins.top + destCenterPartHeight),
				opacity, D2D1_BITMAP_INTERPOLATION_MODE_LINEAR,
				D2D1::RectF(0.f, srcMargins.top, srcMargins.left, srcMargins.top + srcCenterPartHeight)
			);
		}

		if (destCenterPartWidth && destCenterPartHeight)
		{
			// Middle-Center
			context->DrawBitmap(
				bitmap,
				D2D1::RectF(destinationRect.left + destMargins.left, destinationRect.top + destMargins.top, destinationRect.left + destMargins.left + destCenterPartWidth, destinationRect.top + destMargins.top + destCenterPartHeight),
				opacity, D2D1_BITMAP_INTERPOLATION_MODE_LINEAR,
				D2D1::RectF(srcMargins.left, srcMargins.top, srcMargins.left + srcCenterPartWidth, srcMargins.top + srcCenterPartHeight)
			);
		}

		if (destCenterPartHeight)
		{
			// Middle-Right
			context->DrawBitmap(
				bitmap,
				D2D1::RectF(destinationRect.right - destMargins.right, destinationRect.top + destMargins.top, destinationRect.right, destinationRect.top + destMargins.top + destCenterPartHeight),
				opacity, D2D1_BITMAP_INTERPOLATION_MODE_LINEAR,
				D2D1::RectF(bitmapSize.width - srcMargins.right, srcMargins.top, bitmapSize.width, srcMargins.top + srcCenterPartHeight)
			);
		}

		// Bottom-Left
		context->DrawBitmap(
			bitmap,
			D2D1::RectF(destinationRect.left, destinationRect.bottom - destMargins.bottom, destinationRect.left + destMargins.left, destinationRect.bottom),
			opacity, D2D1_BITMAP_INTERPOLATION_MODE_LINEAR,
			D2D1::RectF(0.f, bitmapSize.height - srcMargins.bottom, srcMargins.left, bitmapSize.height)
		);

		if (destCenterPartWidth)
		{
			// Bottom-Center
			context->DrawBitmap(
				bitmap,
				D2D1::RectF(destinationRect.left + destMargins.left, destinationRect.bottom - destMargins.bottom, destinationRect.left + destMargins.left + destCenterPartWidth, destinationRect.bottom),
				opacity, D2D1_BITMAP_INTERPOLATION_MODE_LINEAR,
				D2D1::RectF(srcMargins.left, bitmapSize.height - srcMargins.bottom, srcMargins.left + srcCenterPartWidth, bitmapSize.height)
			);
		}

		// Bottom-Right
		context->DrawBitmap(
			bitmap,
			D2D1::RectF(destinationRect.right - destMargins.right, destinationRect.bottom - destMargins.bottom, destinationRect.right, destinationRect.bottom),
			opacity, D2D1_BITMAP_INTERPOLATION_MODE_LINEAR,
			D2D1::RectF(bitmapSize.width - srcMargins.right, bitmapSize.height - srcMargins.bottom, bitmapSize.width, bitmapSize.height)
		);

		return S_OK;
	}
	// Object pool with key-based reuse and TTL eviction.
	// Released objects are kept for reuse instead of being freed immediately,
	// avoiding repeated allocation of expensive resources (e.g. D3D11 textures).
	// Stale entries are evicted when Cleanup is called (typically at EndDraw).
	// Caller must ensure single-threaded access.
	// Released objects are heap-allocated; only unique_ptr moves, never the object.
	// Acquire transfers ownership to caller; Release transfers it back to the pool.
	template <typename Key, typename T>
	class ObjectPool
	{
		using Clock = std::chrono::steady_clock;
		using TimePoint = Clock::time_point;

		struct Entry
		{
			std::unique_ptr<T> m_object;
			TimePoint m_timestamp;
		};

		std::unordered_multimap<Key, Entry> m_released;

	public:
		~ObjectPool() = default;

		ObjectPool() = default;
		ObjectPool(const ObjectPool&) = delete;
		ObjectPool& operator=(const ObjectPool&) = delete;
		ObjectPool(ObjectPool&&) = delete;
		ObjectPool& operator=(ObjectPool&&) = delete;

		FORCEINLINE std::unique_ptr<T> Acquire(const Key& key)
		{
			const auto it = m_released.find(key);
			if (it != m_released.end())
			{
				auto result = std::move(it->second.m_object);
				m_released.erase(it);
				return result;
			}
			return std::make_unique<T>();
		}

		FORCEINLINE void Release(const Key& key, std::unique_ptr<T> object)
		{
			if (!object)
			{
				return;
			}
			m_released.emplace(
				std::piecewise_construct,
				std::forward_as_tuple(key),
				std::forward_as_tuple(std::move(object), Clock::now())
			);
		}

		template <typename Duration = std::chrono::seconds>
		FORCEINLINE void Cleanup(Duration ttl, std::optional<Key> key = std::nullopt)
		{
			const auto now = Clock::now();
			if (key)
			{
				const auto [begin, end] = m_released.equal_range(*key);
				for (auto it = begin; it != end; )
				{
					if (now - it->second.m_timestamp > ttl)
					{
						it = m_released.erase(it);
					}
					else
					{
						++it;
					}
				}
			}
			else
			{
				for (auto it = m_released.begin(); it != m_released.end(); )
				{
					if (now - it->second.m_timestamp > ttl)
					{
						it = m_released.erase(it);
					}
					else
					{
						++it;
					}
				}
			}
		}
	};

	template <typename T>
	struct ScopedAvgTimer
	{
		const wchar_t* m_tag{};
		std::chrono::steady_clock::time_point m_start{ std::chrono::steady_clock::now() };
		inline static std::chrono::steady_clock::time_point s_last{};
		inline static double s_accumulatedDuration{};
		inline static size_t s_accumulatedCount{};

		explicit ScopedAvgTimer(const wchar_t* tag) noexcept : m_tag(tag) 
		{
			if (!s_last.time_since_epoch().count())
			{
				s_last = std::chrono::steady_clock::now();
			}
		}
		~ScopedAvgTimer() noexcept
		{
			const auto end = std::chrono::steady_clock::now();
			const double us = std::chrono::duration<double, std::micro>(end - m_start).count();
			s_accumulatedDuration += us;
			s_accumulatedCount += 1;

			if (end - s_last >= std::chrono::seconds{ 1 })
			{
				const auto avg = s_accumulatedDuration / s_accumulatedCount;

				wchar_t buf[256]{};
				swprintf_s(buf, L"[OpenGlass] %s avg time: %.3f us (total: %lld)\n", m_tag ? m_tag : L"scope", avg, s_accumulatedCount);
				OutputDebugStringW(buf);

				s_last = end;
				s_accumulatedDuration = 0;
				s_accumulatedCount = 0;
			}
		}
	};

}
namespace OpenGlass
{
	template<class T>
	struct CClassFactoryT : winrt::implements<CClassFactoryT<T>, IClassFactory, winrt::non_agile, winrt::no_weak_ref>
	{
		HRESULT CreateInstance(IUnknown* pUnkOuter, REFIID riid, void** ppvObject) noexcept override
		{
			if (!pUnkOuter)
			{
				*ppvObject = nullptr;
				return winrt::make<T>().as(riid, ppvObject);
			}

			return CLASS_E_NOAGGREGATION;
		}
		HRESULT LockServer(BOOL fLock) noexcept override
		{
			if (fLock)
			{
				++winrt::get_module_lock();
			}
			else
			{
				--winrt::get_module_lock();
			}

			return S_OK;
		}
	};
}
namespace OpenGlass
{
	namespace Color
	{
		FORCEINLINE D2D1_COLOR_F sRGBToscRGB(const D2D1_COLOR_F& color, float sdrBoost)
		{
			auto result = D2D1ConvertColorSpace(
				D2D1_COLOR_SPACE_SRGB,
				D2D1_COLOR_SPACE_SCRGB,
				&color
			);
			if (sdrBoost > 1.f)
			{
				result.r *= sdrBoost;
				result.g *= sdrBoost;
				result.b *= sdrBoost;
			}

			return result;
		}
		FORCEINLINE D2D1_COLOR_F scRGBTosRGB(const D2D1_COLOR_F& color, float sdrBoost)
		{
			auto result = D2D1ConvertColorSpace(
				D2D1_COLOR_SPACE_SCRGB,
				D2D1_COLOR_SPACE_SRGB,
				&color
			);
			if (sdrBoost > 1.f)
			{
				result.r /= sdrBoost;
				result.g /= sdrBoost;
				result.b /= sdrBoost;
			}

			return result;
		}
		FORCEINLINE constexpr D2D1_COLOR_F FromAbgr(DWORD color, bool ignoreAlpha = true)
		{
			return
			{
				static_cast<float>((color & 0x000000FF) >> 0) / 255.f,
				static_cast<float>((color & 0x0000FF00) >> 8) / 255.f,
				static_cast<float>((color & 0x00FF0000) >> 16) / 255.f,
				ignoreAlpha ? 1.f : static_cast<float>((color & 0xFF000000) >> 24) / 255.f
			};
		}
		FORCEINLINE constexpr D2D1_COLOR_F FromArgb(DWORD color, bool ignoreAlpha = true)
		{
			return
			{
				static_cast<float>((color & 0x00FF0000) >> 16) / 255.f,
				static_cast<float>((color & 0x0000FF00) >> 8) / 255.f,
				static_cast<float>((color & 0x000000FF) >> 0) / 255.f,
				ignoreAlpha ? 1.f : static_cast<float>((color & 0xFF000000) >> 24) / 255.f
			};
		}
		FORCEINLINE constexpr DWORD ToArgb(const D2D1_COLOR_F& color, bool ignoreAlpha = true)
		{
			return
				((ignoreAlpha ? 0xFFul : std::min(static_cast<DWORD>(color.a * 255.f + 0.5f), 255ul)) << 24) |
				(std::min(static_cast<DWORD>(color.r * 255.f + 0.5f), 255ul) << 16) |
				(std::min(static_cast<DWORD>(color.g * 255.f + 0.5f), 255ul) << 8) |
				(std::min(static_cast<DWORD>(color.b * 255.f + 0.5f), 255ul) << 0);
		}
		FORCEINLINE constexpr DWORD ToAbgr(const D2D1_COLOR_F& color, bool ignoreAlpha = true)
		{
			return
				((ignoreAlpha ? 0xFFul : std::min(static_cast<DWORD>(color.a * 255.f + 0.5f), 255ul)) << 24) |
				(std::min(static_cast<DWORD>(color.b * 255.f + 0.5f), 255ul) << 16) |
				(std::min(static_cast<DWORD>(color.g * 255.f + 0.5f), 255ul) << 8) |
				(std::min(static_cast<DWORD>(color.r * 255.f + 0.5f), 255ul) << 0);
		}
		FORCEINLINE constexpr winrt::Windows::UI::Color ToWinUIColor(const D2D1_COLOR_F& color)
		{
			return
			{
				static_cast<uint8_t>(std::min(static_cast<DWORD>(color.a * 255.f + 0.5f), 255ul)),
				static_cast<uint8_t>(std::min(static_cast<DWORD>(color.r * 255.f + 0.5f), 255ul)),
				static_cast<uint8_t>(std::min(static_cast<DWORD>(color.g * 255.f + 0.5f), 255ul)),
				static_cast<uint8_t>(std::min(static_cast<DWORD>(color.b * 255.f + 0.5f), 255ul))
			};
		}
	}

}
