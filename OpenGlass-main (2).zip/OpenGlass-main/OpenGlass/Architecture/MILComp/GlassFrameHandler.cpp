#include "pch.h"
#include "Shared.hpp"
#include "GlassFrameHandler.hpp"
#include "AccentOverrider.hpp"
#include "GlassKernel.hpp"
#include "GlassInfra.hpp"
#include "uDwmProjection.hpp"
#include "dwmcoreProjection.hpp"
#include "ReflectionVisual.hpp"
#include "DetourChains.hpp"

using namespace OpenGlass;

namespace OpenGlass::GlassFrameHandler
{
	void MyCGlassColorizationParameters_AdjustWindowColorization(
		uDWM::CGlassColorizationParameters* This,
		[[maybe_unused]] const uDWM::GpCC* colorUnused,
		[[maybe_unused]] float opacity,
		UINT flags
	);

	HRESULT MyCChannel_CombinedGeometryUpdate(
		dwmcore::CChannel* This,
		UINT handleId,
		D2D1_COMBINE_MODE mode,
		UINT geometry1HandleId,
		UINT geometry2HandleId
	);
	void MyCLegacyNonClientBackground_ClearAll(uDWM::CLegacyNonClientBackground* This);
	extern "C" bool MyCLegacyNonClientBackground_HasSomethingToRender(uDWM::CLegacyNonClientBackground* This);
	extern "C" bool MyCLegacyNonClientBackground_HasSomethingToRender_Impl(uDWM::CLegacyNonClientBackground* This);
	HRESULT MyCLegacyNonClientBackground_SetCaptionRect(uDWM::CLegacyNonClientBackground* This, LPCRECT rc);
	HRESULT MyCLegacyNonClientBackground_SetBorderRects(uDWM::CLegacyNonClientBackground* This, LPCRECT rc1, LPCRECT rc2);
	HRESULT MyCLegacyNonClientBackground_SetCaptionColor(uDWM::CLegacyNonClientBackground* This, const D2D1_COLOR_F& color);
	void MyCLegacyNonClientBackground_Destructor(uDWM::CLegacyNonClientBackground* This);

	void MyCRectangleVisual_SetRect(uDWM::CRectangleVisual* This, const D2D1_RECT_F& rc);
	HRESULT MyCTopLevelWindow_UpdateClientBlur(uDWM::CTopLevelWindow* This);
	int MyCTopLevelWindow_EdgeBorderMustBeOpaque(uDWM::CTopLevelWindow* This);

	void MyCTopLevelWindow_Destructor(uDWM::CTopLevelWindow* This);

	Projection::Detour<uDWM::Symbol_CGlassColorizationParameters_AdjustWindowColorization, &MyCGlassColorizationParameters_AdjustWindowColorization> g_CGlassColorizationParameters_AdjustWindowColorization_Org{};

	Projection::Detour<dwmcore::Symbol_CChannel_CombinedGeometryUpdate, &MyCChannel_CombinedGeometryUpdate> g_CChannel_CombinedGeometryUpdate_Org{};
	Projection::Detour<uDWM::Symbol_CLegacyNonClientBackground_ClearAll, &MyCLegacyNonClientBackground_ClearAll> g_CLegacyNonClientBackground_ClearAll_Org{};
	using CLegacyNonClientBackground_HasSomethingToRender_Detour = Projection::CustomDispatchDetour<
		uDWM::Symbol_CLegacyNonClientBackground_HasSomethingToRender,
		&MyCLegacyNonClientBackground_HasSomethingToRender
	>;
	CLegacyNonClientBackground_HasSomethingToRender_Detour g_CLegacyNonClientBackground_HasSomethingToRender_Org{};
	Projection::Detour<uDWM::Symbol_CLegacyNonClientBackground_SetCaptionRect, &MyCLegacyNonClientBackground_SetCaptionRect> g_CLegacyNonClientBackground_SetCaptionRect_Org{};
	Projection::Detour<uDWM::Symbol_CLegacyNonClientBackground_SetBorderRects, &MyCLegacyNonClientBackground_SetBorderRects> g_CLegacyNonClientBackground_SetBorderRects_Org{};
	Projection::Detour<uDWM::Symbol_CLegacyNonClientBackground_SetCaptionColor, &MyCLegacyNonClientBackground_SetCaptionColor> g_CLegacyNonClientBackground_SetCaptionColor_Org{};
	Projection::Detour<uDWM::Symbol_CLegacyNonClientBackground_CLegacyNonClientBackground, &MyCLegacyNonClientBackground_Destructor> g_CLegacyNonClientBackground_Destructor_Org{};

	Projection::Detour<uDWM::Symbol_CRectangleVisual_SetRect, &MyCRectangleVisual_SetRect> g_CRectangleVisual_SetRect_Org{};
	Projection::Detour<uDWM::Symbol_CTopLevelWindow_UpdateClientBlur, &MyCTopLevelWindow_UpdateClientBlur> g_CTopLevelWindow_UpdateClientBlur_Org{};
	DetourChains::TopLevelWindowUpdateNCAreaBackgroundFrameHandlerNode g_CTopLevelWindow_UpdateNCAreaBackground_Org{};
	Projection::Detour<uDWM::Symbol_CTopLevelWindow_EdgeBorderMustBeOpaque, &MyCTopLevelWindow_EdgeBorderMustBeOpaque> g_CTopLevelWindow_EdgeBorderMustBeOpaque_Org{};

	DetourChains::TopLevelWindowValidateVisualFrameHandlerNode g_CTopLevelWindow_ValidateVisual_Org{};
	Projection::Detour<uDWM::Symbol_CTopLevelWindow_CTopLevelWindow, &MyCTopLevelWindow_Destructor> g_CTopLevelWindow_Destructor_Org{};

	std::unordered_map<uDWM::CLegacyNonClientBackground*, winrt::com_ptr<uDWM::CSolidRectangleVisual>> g_effectVisualMap{};
	winrt::com_ptr<uDWM::CSolidRectangleVisual> GetOrCreateEffectVisual(uDWM::CLegacyNonClientBackground* background, bool createIfNecessary)
	{
		if (createIfNecessary)
		{
			auto& effectVisual = g_effectVisualMap[background];
			if (!effectVisual)
			{
				THROW_IF_FAILED(
					uDWM::CSolidRectangleVisual::Create(
						effectVisual.put()
					)
				);
				THROW_IF_FAILED(
					background->GetVisualCollection()->InsertRelative(
						effectVisual.get(),
						nullptr,
						false,
						true
					)
				);
			}

			return effectVisual;
		}

		const auto it = g_effectVisualMap.find(background);
		return it == g_effectVisualMap.end() ? nullptr : it->second;
	}
	void RemoveEffectVisual(uDWM::CLegacyNonClientBackground* background)
	{
		if (const auto it = g_effectVisualMap.find(background); it != g_effectVisualMap.end())
		{
			const auto& effectVisual = it->second;
			const auto parent = effectVisual->GetTransformParent();
			if (parent)
			{
				THROW_IF_FAILED(parent->GetVisualCollection()->Remove(effectVisual.get()));
			}
			g_effectVisualMap.erase(it);
		}
	}
	void RemoveAllEffectVisuals()
	{
		for (const auto& [background, effectVisual] : g_effectVisualMap)
		{
			const auto parent = effectVisual->GetTransformParent();
			if (parent)
			{
				FAIL_FAST_IF_FAILED_MSG(parent->GetVisualCollection()->Remove(effectVisual.get()), "Unable to remove an effect visual during shutdown");
			}
		}
		g_effectVisualMap.clear();
	}

	HRESULT UpdateWindowVisuals(uDWM::CTopLevelWindow* window);

	RECT g_innerBorderRect{};
	RECT g_outerBorderRect{};
}

HRESULT GlassFrameHandler::UpdateWindowVisuals(uDWM::CTopLevelWindow* window)
{
	const auto offset = window->GetOffset();
	if (offset.x == -32000 && offset.y == -32000)
	{
		return S_OK;
	}
	RETURN_IF_FAILED(AccentOverrider::UpdateMarkers(window));
	return CReflectionVisual::UpdateWindow(window);
}

void GlassFrameHandler::MyCGlassColorizationParameters_AdjustWindowColorization(
	uDWM::CGlassColorizationParameters* This,
	[[maybe_unused]] const uDWM::GpCC* colorUnused,
	[[maybe_unused]] float opacity,
	UINT flags
)
{
	const auto status = GlassInfra::g_window ?
		GlassKernel::GetWindowStatus(GlassInfra::g_window, (flags & 1) != 0) : std::bitset<2>{ flags & 1u };
	const auto active = status.test(0);
	const auto maximized = status.test(1);

	This->color = Color::ToAbgr(
		Color::scRGBTosRGB(
			GlassKernel::RealizeWindowColorization(
				GlassKernel::GetBaseColor(Shared::IsTransparencyDisabled(), maximized),
				GlassKernel::GetSourceColor(active),
				GlassKernel::GetColorizationOpacity(active, maximized),
				Shared::IsTransparencyDisabled(),
				false
			).GetEffectivescRGBBlendColor(0.f),
			0.f
		)
	);
	This->afterglow = 0;
	This->colorBalance = 100;
	This->afterglowBalance = 0;
	This->blurBalance = 0;
	This->windowColorization = TRUE;
	This->glassAttribute = 0;

}

HRESULT GlassFrameHandler::MyCChannel_CombinedGeometryUpdate(
	dwmcore::CChannel* This,
	UINT handleId,
	D2D1_COMBINE_MODE mode,
	UINT geometry1HandleId,
	UINT geometry2HandleId
)
{
	if (GlassInfra::g_window)
	{
		mode = static_cast<D2D1_COMBINE_MODE>(GlassKernel::GetWindowStatus(GlassInfra::g_window).to_ulong());
	}

	return g_CChannel_CombinedGeometryUpdate_Org(This, handleId, mode, geometry1HandleId, geometry2HandleId);
}
void GlassFrameHandler::MyCLegacyNonClientBackground_ClearAll(uDWM::CLegacyNonClientBackground* This)
{
	CReflectionVisual::RemoveSlot(uDWM::TryGetWindowFromVisual(This), CReflectionVisual::Slot::NonClient);
	RemoveEffectVisual(This);
	return g_CLegacyNonClientBackground_ClearAll_Org(This);
}
bool GlassFrameHandler::MyCLegacyNonClientBackground_HasSomethingToRender_Impl(uDWM::CLegacyNonClientBackground* This)
{
	return g_CLegacyNonClientBackground_HasSomethingToRender_Org.Dispatch(
		[](uDWM::CLegacyNonClientBackground* background)
		{
			return g_effectVisualMap.find(background) != g_effectVisualMap.end();
		},
		This
	);
}
HRESULT GlassFrameHandler::MyCLegacyNonClientBackground_SetCaptionRect(uDWM::CLegacyNonClientBackground* This, LPCRECT rc)
{
	const auto window = uDWM::TryGetWindowFromVisual(This);
	if (!IsRectEmpty(&g_outerBorderRect))
	{
		const auto effectVisual = GetOrCreateEffectVisual(This, true);
		winrt::com_ptr<CReflectionVisual> reflectionVisual;
		RETURN_IF_FAILED(CReflectionVisual::GetOrCreate(window, CReflectionVisual::Slot::NonClient, effectVisual.get(), reflectionVisual.put()));

		wil::unique_hrgn windowRgn{ nullptr };
		wil::unique_hrgn clientRgn{ nullptr };

		const auto diameter = Shared::g_roundRectRadius * 2;
		// HACK: there is a fxxking gdi bug introduced in windows 11 25h2 that causes CreateRoundRectRgn to shrink the region by 1 pixel in both dimensions,
		// which is exactly the case for our border region when rounded corners are enabled,
		// causing our effect visual to be clipped by 1 pixel on the right and bottom sides.
		// As a workaround, we can simply add 1 pixel to the width and height when creating the rounded region,
		// which does not cause any visual issue but can avoid the GDI bug.
		windowRgn.reset(
			diameter ?
			CreateRoundRectRgn(
				g_outerBorderRect.left,
				g_outerBorderRect.top,
				g_outerBorderRect.right + 1,
				g_outerBorderRect.bottom + 1,
				diameter,
				diameter
			) :
			CreateRectRgn(
				g_outerBorderRect.left,
				g_outerBorderRect.top,
				g_outerBorderRect.right,
				g_outerBorderRect.bottom
			)
		);
		RETURN_LAST_ERROR_IF_NULL(windowRgn);

		bool isSheetOfGlass = g_innerBorderRect.left == 0 && g_innerBorderRect.top == 0 && g_innerBorderRect.right == 0 && g_innerBorderRect.bottom == 0;
		clientRgn.reset(
			isSheetOfGlass ?
			CreateRectRgn(0, 0, 0, 0) :
			CreateRectRgn(
				rc->left,
				rc->bottom,
				rc->right,
				g_innerBorderRect.bottom
			)
		);
		RETURN_LAST_ERROR_IF_NULL(clientRgn);

		RETURN_IF_WIN32_BOOL_FALSE(CombineRgn(windowRgn.get(), windowRgn.get(), clientRgn.get(), RGN_DIFF));

		RECT rgnBox{};
		RETURN_LAST_ERROR_IF(GetRgnBox(windowRgn.get(), &rgnBox) == NULLREGION);
		POINT offset{ 0, 0 };
		SIZE size{ rgnBox.right, rgnBox.bottom };

		// NOTE: you MUST use SetRect otherwise the entire visual will be invisible and you will have higher posibility to encounter mysterious compositor bug.
		D2D1_RECT_F rect
		{
			static_cast<float>(0.f),
			static_cast<float>(0.f),
			static_cast<float>(rgnBox.right),
			static_cast<float>(rgnBox.bottom)
		};
		effectVisual->SetRect(rect);
		winrt::com_ptr<uDWM::CRgnGeometryProxy> regionGeometry{};
		RETURN_IF_FAILED(uDWM::ResourceHelper::CreateGeometryFromHRGN(windowRgn.get(), regionGeometry.put()));

		RETURN_IF_FAILED(GlassInfra::UpdateGlassMarker(effectVisual.get(), regionGeometry.get(), GlassKernel::GetWindowStatus(window)));

		reflectionVisual->SetSize(&size);

		RETURN_IF_FAILED(reflectionVisual->UpdateForWindow(window, CReflectionVisual::Slot::NonClient));
	}
	else
	{
		CReflectionVisual::RemoveSlot(window, CReflectionVisual::Slot::NonClient);
		RemoveEffectVisual(This);
	}

	RECT emptyRect{};
	return g_CLegacyNonClientBackground_SetCaptionRect_Org(This, &emptyRect);
}
HRESULT GlassFrameHandler::MyCLegacyNonClientBackground_SetBorderRects(uDWM::CLegacyNonClientBackground* This, LPCRECT rc1, LPCRECT rc2)
{
	// patch microsoft's terrible code
	// IsSheetOfGlass == true && IsHighContrastMode == true
	//
	/*bool isSheetOfGlass = rc1->left == 0 && rc1->top == 0 && rc1->right == 0 && rc1->bottom == 0;
	if (isSheetOfGlass)
	{
		const auto center = (rc2->left + rc2->right) / 2;
		const auto middle = (rc2->top + rc2->bottom) / 2;
		const_cast<LPRECT>(rc1)->left = center;
		const_cast<LPRECT>(rc1)->right = center;
		const_cast<LPRECT>(rc1)->top = middle;
		const_cast<LPRECT>(rc1)->bottom = middle;
	}*/

	g_innerBorderRect = *rc1;
	g_outerBorderRect = *rc2;

	RECT emptyRect{};
	return g_CLegacyNonClientBackground_SetBorderRects_Org(This, &emptyRect, &emptyRect);
}
HRESULT GlassFrameHandler::MyCLegacyNonClientBackground_SetCaptionColor(uDWM::CLegacyNonClientBackground* This, const D2D1_COLOR_F& color)
{
	const auto effectVisual = GetOrCreateEffectVisual(This, false);
	if (effectVisual)
	{
		RETURN_IF_FAILED(effectVisual->UpdateColor(color));
	}

	return g_CLegacyNonClientBackground_SetCaptionColor_Org(This, color);
}
void GlassFrameHandler::MyCLegacyNonClientBackground_Destructor(uDWM::CLegacyNonClientBackground* This)
{
	const auto window = uDWM::TryGetWindowFromVisual(This);
	CReflectionVisual::RemoveSlot(window, CReflectionVisual::Slot::NonClient);
	RemoveEffectVisual(This);
	return g_CLegacyNonClientBackground_Destructor_Org(This);
}

void GlassFrameHandler::MyCRectangleVisual_SetRect(uDWM::CRectangleVisual* This, const D2D1_RECT_F& rc)
{
	const auto window = uDWM::TryGetWindowFromVisual(This);
	if (
		!window ||
		window->GetClientBlurVisual() != This
	)
	{
		return g_CRectangleVisual_SetRect_Org(This, rc);
	}

	winrt::com_ptr<CReflectionVisual> reflectionVisual;
	THROW_IF_FAILED(CReflectionVisual::GetOrCreate(window, CReflectionVisual::Slot::ClientBlur, This, reflectionVisual.put()));

	SIZE size{ static_cast<LONG>(rc.right), static_cast<LONG>(rc.bottom) };
	reflectionVisual->SetSize(&size);

	if (const auto hr = reflectionVisual->UpdateForWindow(window, CReflectionVisual::Slot::ClientBlur); FAILED(hr))
	{
		LOG_HR(hr);
		return;
	}

	// HACK: SetRect is not SetViewbox,
	// microsoft's code mistakenly applies the offset to the rect,
	// which causes the blur to be misaligned when DwmExtendFrameIntoClientArea is used.
	auto adjustedRect = rc;
	adjustedRect.left = adjustedRect.top = 0;
	return g_CRectangleVisual_SetRect_Org(This, adjustedRect);
}
HRESULT GlassFrameHandler::MyCTopLevelWindow_UpdateClientBlur(uDWM::CTopLevelWindow* This)
{
	const auto hr = g_CTopLevelWindow_UpdateClientBlur_Org(This);
	RETURN_IF_FAILED(hr);

	if (const auto clientBlurVisual = This->GetClientBlurVisual())
	{
		// Native NULL-region blur uses its rectangle/window geometry directly.
		// Mark the selected clip after native rebuilding, retaining its exact shape.
		RETURN_IF_FAILED(GlassInfra::UpdateGlassMarker(clientBlurVisual, clientBlurVisual->GetClip(), GlassKernel::GetWindowStatus(This)));
	}
	else
	{
		CReflectionVisual::RemoveSlot(This, CReflectionVisual::Slot::ClientBlur);
	}
	return hr;
}

HRESULT GlassFrameHandler::MyCTopLevelWindow_UpdateNCAreaBackground(uDWM::CTopLevelWindow* This)
{
	// HACK: UpdateClientBlur always checks current dirty flags to decide whether to update blur or not,
	// in some cases (e.g. when window is maximized/activated) the window states can be changed without UpdateClientBlur being called,
	// which causes the glass to not update and thus look wrong.
	// Forcing an UpdateClientBlur call here seems to fix the issue.
	This->OnBlurBehindUpdated();
	return g_CTopLevelWindow_UpdateNCAreaBackground_Org(This);
}

int GlassFrameHandler::MyCTopLevelWindow_EdgeBorderMustBeOpaque(uDWM::CTopLevelWindow* This)
{
	// When the window is inactive and EdgeBorderMustBeOpaque is false,
	// the border rect computed in CTopLevelWindow::UpdateNCAreaGeometry shrinks to zero (border visual removed, only caption remains).
	// This shrinks the visual's SetRect to caption size, which causes the occlusion pass to pass because
	// COcclusionContext::PreSubgraph contains a size threshold optimization at 0x180069838:
	//   comiss xmm10, 75000.0   ; visual area vs threshold
	//   jb    skip_check         ; area < 75000 -> bypass the stricter occlusion checks
	// When SetRect is set to the full window rect, the visual area exceeds 75000 px^2,
	// triggering additional validation that disables occlusion for the subtree.

	if (Shared::g_dontDeflateInactiveFrameGeometry)
	{
		return TRUE;
	}

	return g_CTopLevelWindow_EdgeBorderMustBeOpaque_Org(This);
}

HRESULT GlassFrameHandler::MyCTopLevelWindow_ValidateVisual(uDWM::CTopLevelWindow* This)
{
	auto data = This->GetData();
	if (!data)
	{
		return g_CTopLevelWindow_ValidateVisual_Org(This);
	}

	GlassInfra::g_window = This;
	const auto hr = g_CTopLevelWindow_ValidateVisual_Org(This);
	LOG_IF_FAILED(UpdateWindowVisuals(This));
	GlassInfra::g_window = nullptr;
	return hr;
}

void GlassFrameHandler::MyCTopLevelWindow_Destructor(uDWM::CTopLevelWindow* This)
{
	CReflectionVisual::RemoveWindow(This);
	return g_CTopLevelWindow_Destructor_Org(This);
}

void GlassFrameHandler::Update([[maybe_unused]] GlassEngine::UpdateType type)
{
}

void GlassFrameHandler::Startup()
{
	if (Shared::g_disabledHooks.test(Shared::DisabledHooks_GlassFrameHandler))
	{
		return;
	}

	HookHelper::ApplyInlineHooks(
		std::initializer_list<HookHelper::DetourInfo>
		{
			{ &g_CGlassColorizationParameters_AdjustWindowColorization_Org },

			{ &g_CChannel_CombinedGeometryUpdate_Org },
			{ &g_CLegacyNonClientBackground_ClearAll_Org },
			{ &g_CLegacyNonClientBackground_HasSomethingToRender_Org },
			{ &g_CLegacyNonClientBackground_SetCaptionRect_Org },
			{ &g_CLegacyNonClientBackground_SetBorderRects_Org },
			{ &g_CLegacyNonClientBackground_SetCaptionColor_Org },
			{ &g_CLegacyNonClientBackground_Destructor_Org },

			{ &g_CRectangleVisual_SetRect_Org },
			{ &g_CTopLevelWindow_UpdateClientBlur_Org },
			{ &g_CTopLevelWindow_UpdateNCAreaBackground_Org },
			{ &g_CTopLevelWindow_EdgeBorderMustBeOpaque_Org },

			{ &g_CTopLevelWindow_ValidateVisual_Org },
			{ &g_CTopLevelWindow_Destructor_Org },
		}
	);
}

void GlassFrameHandler::Shutdown()
{
	if (Shared::g_disabledHooks.test(Shared::DisabledHooks_GlassFrameHandler))
	{
		return;
	}

	HookHelper::ApplyInlineHooks(
		std::initializer_list<HookHelper::DetourInfo>
		{
			{ &g_CGlassColorizationParameters_AdjustWindowColorization_Org },

			{ &g_CChannel_CombinedGeometryUpdate_Org },
			{ &g_CLegacyNonClientBackground_ClearAll_Org },
			{ &g_CLegacyNonClientBackground_HasSomethingToRender_Org },
			{ &g_CLegacyNonClientBackground_SetCaptionRect_Org },
			{ &g_CLegacyNonClientBackground_SetBorderRects_Org },
			{ &g_CLegacyNonClientBackground_SetCaptionColor_Org },
			{ &g_CLegacyNonClientBackground_Destructor_Org },

			{ &g_CRectangleVisual_SetRect_Org },
			{ &g_CTopLevelWindow_UpdateClientBlur_Org },
			{ &g_CTopLevelWindow_UpdateNCAreaBackground_Org },
			{ &g_CTopLevelWindow_EdgeBorderMustBeOpaque_Org },

			{ &g_CTopLevelWindow_ValidateVisual_Org },
			{ &g_CTopLevelWindow_Destructor_Org },
		}
	);

}

void GlassFrameHandler::Cleanup()
{
	CReflectionVisual::RemoveSlot(CReflectionVisual::Slot::NonClient);
	CReflectionVisual::RemoveSlot(CReflectionVisual::Slot::ClientBlur);
	RemoveAllEffectVisuals();
}
